package FicherosBinarios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class mainEjer1 {
	public static void EscribirPersonas(String ruta) {
		try {
			//creo descriptor de fichero de 0
			File fichero=new File(ruta);
			//Indico que abro el fichero para escribir
			FileOutputStream escritura= new FileOutputStream(fichero);
			//Indico que voy a escribir objetos
			ObjectOutputStream oos =new ObjectOutputStream(escritura);
			
			Persona p1= new Persona("Paco",50);
			Persona p2= new Persona("Pedro",10);
			
			oos.writeObject(p1);
			oos.writeObject(p2);
			oos.close();
			
		}catch(FileNotFoundException e) { 
			e.printStackTrace();
		}catch(IOException e ) { 
			e.getStackTrace();
		}
	}
	
	public static void lecturaObjetos(String ruta) {
		try {
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File(ruta)));
			
			Persona p1= new Persona("Paco",50);
			Persona p2= new Persona("Pedro",10);
			
			System.out.println(p1);
			System.out.println(p2);
			ois.close();
		}catch(FileNotFoundException  e) { //porque necesito que me devuelva un error la clase
			e.printStackTrace();
		}catch(IOException e ) { 
			e.getStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		String ruta="ejer1.bin";

		EscribirPersonas(ruta);
		lecturaObjetos(ruta);

	}

}
