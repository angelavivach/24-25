package FicherosBinarios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main {
	
	public static void escribirBinario(String ruta) {
		File fichero= new File(ruta);
		
		try {
			FileOutputStream fos = new FileOutputStream(fichero);
			String datos="Vamos a escribir una prueba de datos";
			fos.write(datos.getBytes()); //se convierte en bytes
			fos.close(); //si no cerramos no podremkos leer porque sigue en proceso de lectura
		}catch(IOException e) { // la e es el nombre de la variable
			e.getStackTrace();
		}
	}
	
	public static void lecturaBinario(String ruta) {
		File fichero=new File(ruta);
		
		try {
			FileInputStream fis= new FileInputStream(fichero);
			int i;
			while((i=fis.read())!=-1) { //cuando llega al final del fichero nnos devuelve -1
				System.out.print((char)i);
			}
		}catch(IOException e) {
			e.getStackTrace();
		}
	}
	
	public static void EscribirCoches(String ruta2) {
		try {
			//creo descriptor de fichero de 0
			File fichero=new File(ruta2);
			//Indico que abro el fichero para escribir
			FileOutputStream escritura= new FileOutputStream(fichero);
			//Indico que voy a escribir objetos
			ObjectOutputStream oos =new ObjectOutputStream(escritura);
			
			Coche c1= new Coche(5,"opel","astra",500,200,20000);
			Coche c2= new Coche(2,"citroen","c3",100,1900,10000);
			
			oos.writeObject(c1);
			oos.writeObject(c2);
			oos.close();
			
		}catch(FileNotFoundException e) { 
			e.printStackTrace();
		}catch(IOException e ) { 
			e.getStackTrace();
		}
	}
	
	public static void lecturaObjetos(String ruta) {
		try {
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File(ruta)));
			
			Coche coche1 = (Coche)ois.readObject();
			Coche coche2 = (Coche)ois.readObject();
			
			System.out.println(coche1.getNumPuertas() +" " + coche1.getMarca()+" "+ coche1.getModelo()+" "+ coche1.getNumCaballos()+" "+coche1.getCilindrada()+ " "+ coche1.getPrecio());
			System.out.println(coche2);
			ois.close();
		}catch(ClassNotFoundException e) { //porque necesito que me devuelva un error la clase
			e.printStackTrace();
		}catch(IOException e ) { 
			e.getStackTrace();
		}
		
	}

	public static void main(String[] args) {
		String ruta="fichero.bin";
		String ruta2="ficheroObjetos.bin";
		escribirBinario(ruta);
		lecturaBinario( ruta);
		EscribirCoches(ruta2);
		lecturaObjetos(ruta2);

	}

}
