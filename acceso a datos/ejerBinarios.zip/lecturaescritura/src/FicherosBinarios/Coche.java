package FicherosBinarios;

import java.io.Serializable;

public class Coche implements Serializable { //se recompierte en un foco de datos
	private int numPuertas;
	private String marca;
	private String modelo;
	private int numCaballos;
	private int cilindrada;
	private double precio;
	
	public Coche() {
		
	}
	
	public Coche(int numPuertas, String marca, String modelo, int numCaballos, int cilindrada, double precio) {
		super();
		this.numPuertas = numPuertas;
		this.marca = marca;
		this.modelo = modelo;
		this.numCaballos = numCaballos;
		this.cilindrada = cilindrada;
		this.precio = precio;
	}
	
	public int getNumPuertas() {
		return numPuertas;
	}
	public void setNumPuertas(int numPuertas) {
		this.numPuertas = numPuertas;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getNumCaballos() {
		return numCaballos;
	}
	public void setNumCaballos(int numCaballos) {
		this.numCaballos = numCaballos;
	}
	public int getCilindrada() {
		return cilindrada;
	}
	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Coche numPuertas=" + numPuertas + ", marca=" + marca + ", modelo=" + modelo + ", numCaballos="
				+ numCaballos + ", cilindrada=" + cilindrada + ", precio=" + precio + " ";
	}

}
