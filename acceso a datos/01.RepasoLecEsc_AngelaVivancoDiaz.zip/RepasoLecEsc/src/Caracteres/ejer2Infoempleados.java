package Caracteres;

import java.io.*;
import java.util.*;

public class ejer2Infoempleados {
	private static void crearFicheroEmpleados(String nombreFichero) {
        String[] datos = {
            "Juan,3000,40",
            "María,2500,35",
            "Pedro,4500,50",
            "Lucía,3200,45",
            "Antonio,2800,38"
        };

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreFichero))) {
            for (String dato : datos) {
                writer.write(dato);
                writer.newLine();
            }
            System.out.println("Fichero de empleados creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error al crear el fichero: " + e.getMessage());
        }
    }

    private static Map<String, Empleado> leerEmpleadosDesdeFichero(String nombreFichero) {
        Map<String, Empleado> empleados = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nombreFichero))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                String nombre = partes[0].trim();
                double salario = Double.parseDouble(partes[1].trim());
                int horas = Integer.parseInt(partes[2].trim());
                empleados.put(nombre, new Empleado(nombre, salario, horas));
            }
        } catch (IOException e) {
            System.err.println("Error al leer el fichero: " + e.getMessage());
            return null;
        }
        return empleados;
    }

    private static void generarInforme(Map<String, Empleado> empleados) {
        double totalSalarios = calcularTotalSalarios(empleados);
        double mediaSalarios = calcularMediaSalarios(totalSalarios, empleados.size());

        // Imprimir el informe
        System.out.println("Informe de Empleados:");
        System.out.println("Total de salarios a pagar: " + totalSalarios);
        System.out.println("Media de salarios: " + mediaSalarios);
        System.out.println("\nDetalles de empleados:");

        for (Empleado empleado : empleados.values()) {
            String estado = empleado.getSalario() > mediaSalarios ? "por encima" : "por debajo";
            System.out.printf("%s - Salario: %.2f horas: %d (%s del salario promedio)\n", 
                              empleado.getNombre(), empleado.getSalario(), empleado.getHoras(), estado);
        }
    }

    private static double calcularTotalSalarios(Map<String, Empleado> empleados) {
        double total = 0;
        for (Empleado empleado : empleados.values()) {
            total += empleado.getSalario();
        }
        return total;
    }

    private static double calcularMediaSalarios(double totalSalarios, int numEmpleados) {
        return numEmpleados > 0 ? totalSalarios / numEmpleados : 0;
    }

    static class Empleado {
        private String nombre;
        private double salario;
        private int horas;

        public Empleado(String nombre, double salario, int horas) {
            this.nombre = nombre;
            this.salario = salario;
            this.horas = horas;
        }

        public String getNombre() {
            return nombre;
        }

        public double getSalario() {
            return salario;
        }

        public int getHoras() {
            return horas;
        }
    }
    
    public static void main(String[] args) {
        String nombreFichero = "empleados.txt";
        
        // Crear el fichero con datos de empleados
        crearFicheroEmpleados(nombreFichero);

        // Leer el fichero y generar el informe
        Map<String, Empleado> empleados = leerEmpleadosDesdeFichero(nombreFichero);

        if (empleados != null) {
            generarInforme(empleados);
        }
    }

}
