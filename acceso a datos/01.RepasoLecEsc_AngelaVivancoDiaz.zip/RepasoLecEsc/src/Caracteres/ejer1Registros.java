package Caracteres;

import java.io.*;
import java.util.*;

public class ejer1Registros {
	private static void crearFicheroVentas(String nombreFichero) {
        String[] datos = {
            "ProductoA,200",
            "ProductoB,150",
            "ProductoC,300",
            "ProductoD,250",
            "ProductoE,100"
        };

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreFichero))) {
            for (String dato : datos) {
                writer.write(dato);
                writer.newLine();
            }
            System.out.println("Fichero de ventas creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error al crear el fichero: " + e.getMessage());
        }
    }

    private static Map<String, Integer> leerVentasDesdeFichero(String nombreFichero) {
        Map<String, Integer> ventas = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nombreFichero))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                String producto = partes[0].trim();
                int cantidad = Integer.parseInt(partes[1].trim());
                ventas.put(producto, cantidad);
            }
        } catch (IOException e) {
            System.err.println("Error al leer el fichero: " + e.getMessage());
            return null;
        }
        return ventas;
    }

    private static void generarInforme(Map<String, Integer> ventas) {
        int totalVentas = calcularTotalVentas(ventas);
        double ventaPromedio = calcularVentaPromedio(totalVentas, ventas.size());
        String productoMayorVenta = encontrarProductoMayorVenta(ventas);

        // Imprimir el informe
        System.out.println("Informe de Ventas:");
        System.out.println("Total de ventas: " + totalVentas);
        System.out.println("Venta promedio por producto: " + ventaPromedio);
        System.out.println("Producto con mayor venta: " + productoMayorVenta);
    }

    private static int calcularTotalVentas(Map<String, Integer> ventas) {
        int total = 0;
        for (int cantidad : ventas.values()) {
            total += cantidad;
        }
        return total;
    }

    private static double calcularVentaPromedio(int totalVentas, int numProductos) {
        return numProductos > 0 ? (double) totalVentas / numProductos : 0;
    }

    private static String encontrarProductoMayorVenta(Map<String, Integer> ventas) {
        String productoMayor = "";
        int mayorVenta = 0;

        for (Map.Entry<String, Integer> entry : ventas.entrySet()) {
            if (entry.getValue() > mayorVenta) {
                mayorVenta = entry.getValue();
                productoMayor = entry.getKey();
            }
        }
        return productoMayor + " (" + mayorVenta + ")";
    }
    
    public static void main(String[] args) {
        String nombreFichero = "ventas.txt";
        
        // Crear el fichero con datos de ventas
        crearFicheroVentas(nombreFichero);

        // Leer el fichero y generar el informe
        Map<String, Integer> ventas = leerVentasDesdeFichero(nombreFichero);

        if (ventas != null) {
            generarInforme(ventas);
        }
    }
}
