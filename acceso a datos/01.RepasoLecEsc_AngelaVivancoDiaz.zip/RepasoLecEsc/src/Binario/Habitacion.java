package Binario;

import java.io.Serializable;
import java.time.LocalDate;

public class Habitacion implements Serializable {
	private static final long serialVersionUID = 1L; // Para la serialización
    private int numero;
    private boolean ocupada;
    private LocalDate fechaEntrada;
    private int diasReservados;
    private String huesped;
    
    public Habitacion(int numero) {
        this.numero = numero;
        this.ocupada = false;
        this.fechaEntrada = null;
        this.diasReservados = 0;
        this.huesped = null;
    }

    public int getNumero() {
        return numero;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void reservar(LocalDate fechaEntrada, int diasReservados, String huesped) {
        this.ocupada = true;
        this.fechaEntrada = fechaEntrada;
        this.diasReservados = diasReservados;
        this.huesped = huesped;
    }

    public void liberar() {
        this.ocupada = false;
        this.fechaEntrada = null;
        this.diasReservados = 0;
        this.huesped = null;
    }

    public LocalDate getFechaEntrada() {
        return fechaEntrada;
    }

    public int getDiasReservados() {
        return diasReservados;
    }

    public String getHuesped() {
        return huesped;
    }

    public String estado() {
        return ocupada ? "Ocupada por " + huesped + " desde " + fechaEntrada + " por " + diasReservados + " días" : "Libre";
    }

}
