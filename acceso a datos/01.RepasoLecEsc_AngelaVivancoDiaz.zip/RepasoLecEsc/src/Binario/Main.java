package Binario;

import java.io.*;
import java.util.Scanner;
import java.time.LocalDate;

public class Main {
	public static void main(String[] args) {
		Hotel hotel = new Hotel(10); // Creando un hotel con 10 habitaciones
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nSistema de Reservas de Hotel");
            System.out.println("1. Reservar habitación");
            System.out.println("2. Liberar habitación");
            System.out.println("3. Ver habitaciones disponibles");
            System.out.println("4. Calcular media de ocupaciones");
            System.out.println("5. Listar huéspedes");
            System.out.println("6. Mostrar estado de habitaciones");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Número de habitación: ");
                    int numReserva = scanner.nextInt();
                    System.out.print("Fecha de entrada (YYYY-MM-DD): ");
                    LocalDate fechaEntrada = LocalDate.parse(scanner.next());
                    System.out.print("Días reservados: ");
                    int diasReservados = scanner.nextInt();
                    scanner.nextLine(); // Limpiar el buffer
                    System.out.print("Nombre del huésped: ");
                    String huesped = scanner.nextLine(); // Usar nextLine para leer el nombre completo
                    hotel.reservarHabitacion(numReserva, fechaEntrada, diasReservados, huesped);
                    break;

                case 2:
                    System.out.print("Número de habitación a liberar: ");
                    int numLiberar = scanner.nextInt();
                    hotel.liberarHabitacion(numLiberar);
                    break;

                case 3:
                    System.out.println("Habitaciones disponibles: " + hotel.contarHabitacionesLibres());
                    break;

                case 4:
                    System.out.println("Media de ocupaciones: " + hotel.calcularMediaOcupaciones());
                    break;

                case 5:
                    System.out.println("Huéspedes actuales: " + hotel.listarHuespedes());
                    break;

                case 6:
                    hotel.mostrarEstadoHabitaciones();
                    break;

                case 0:
                    System.out.println("Saliendo del sistema.");
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }
    
}
