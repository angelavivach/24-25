package ejerBinario;

import java.io.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Libreria implements Serializable {
    private List<Libro> libros;

    public Libreria() {
        this.libros = new ArrayList<>();
    }

    // Método para insertar un libro
    public void insertarLibro(String titulo, String autor, double precio) {
        Libro nuevoLibro = new Libro(titulo, autor, precio);
        libros.add(nuevoLibro);
    }

    // Método para listar todos los libros
    public void listarLibros() {
        if (libros.isEmpty()) {
            System.out.println("No hay libros disponibles en la librería.");
        } else {
            for (Libro libro : libros) {
                System.out.println(libro);
            }
        }
    }

    // Método para ordenar los libros por precio
    public void ordenarPorPrecio() {
        Collections.sort(libros, Comparator.comparingDouble(Libro::getPrecio));
        System.out.println("Libros ordenados por precio:");
        listarLibros();
    }

    // Método para filtrar libros dentro de un rango de precios
    public void filtrarPorRangoPrecio(double precioMin, double precioMax) {
        List<Libro> librosFiltrados = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getPrecio() >= precioMin && libro.getPrecio() <= precioMax) {
                librosFiltrados.add(libro);
            }
        }

        if (librosFiltrados.isEmpty()) {
            System.out.println("No hay libros dentro del rango de precio entre $" + precioMin + " y $" + precioMax + ".");
        } else {
            System.out.println("Libros entre $" + precioMin + " y $" + precioMax + ":");
            for (Libro libro : librosFiltrados) {
                System.out.println(libro);
            }
        }
    }

    // Método para guardar los libros en un fichero binario
    public void guardarEnFichero(String nombreFichero) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreFichero))) {
            oos.writeObject(this.libros);
            System.out.println("Datos guardados correctamente en " + nombreFichero);
        } catch (IOException e) {
            System.out.println("Error al guardar los datos: " + e.getMessage());
        }
    }

    // Método para cargar los libros desde un fichero binario
    @SuppressWarnings("unchecked")
    public void cargarDesdeFichero(String nombreFichero) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreFichero))) {
            this.libros = (List<Libro>) ois.readObject();
            System.out.println("Datos cargados correctamente desde " + nombreFichero);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos: " + e.getMessage());
        }
    }


// Clase principal para probar el programa

    public static void main(String[] args) {
        Libreria libreria = new Libreria();

        // Insertar libros en la librería
        libreria.insertarLibro("Cien años de soledad", "Gabriel García Márquez", 25.50);
        libreria.insertarLibro("El principito", "Antoine de Saint-Exupéry", 15.99);
        libreria.insertarLibro("Don Quijote de la Mancha", "Miguel de Cervantes", 35.00);

        // Listar todos los libros
        System.out.println("Lista de libros antes de guardar:");
        libreria.listarLibros();

        // Guardar libros en un fichero binario
        libreria.guardarEnFichero("libros.bin");

        // Crear una nueva librería vacía y cargar los libros desde el fichero binario
        Libreria nuevaLibreria = new Libreria();
        nuevaLibreria.cargarDesdeFichero("libros.bin");

        // Listar los libros cargados desde el fichero
        System.out.println("\nLista de libros después de cargar:");
        nuevaLibreria.listarLibros();
    }
}