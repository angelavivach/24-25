package ejerBinario;

import java.io.*;

import java.util.ArrayList;
import java.util.List;

public class GestionAlumnos implements Serializable {
    private List<Alumno> alumnos;

    public GestionAlumnos() {
        this.alumnos = new ArrayList<>();
    }

    // Método para dar de alta un alumno (insertar un nuevo alumno)
    public void insertarAlumno(String nombre, String apellido, double nota) {
        Alumno nuevoAlumno = new Alumno(nombre, apellido, nota);
        alumnos.add(nuevoAlumno);
    }

    // Método para actualizar la nota de un alumno
    public void actualizarNota(String nombre, String apellido, double nuevaNota) {
        for (Alumno alumno : alumnos) {
            if (alumno.getNombre().equalsIgnoreCase(nombre) && alumno.getApellido().equalsIgnoreCase(apellido)) {
                alumno.setNota(nuevaNota);
                System.out.println("Nota actualizada para " + alumno);
                return;
            }
        }
        System.out.println("Alumno no encontrado.");
    }

    // Método para listar todos los alumnos
    public void listarAlumnos() {
        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos registrados.");
        } else {
            for (Alumno alumno : alumnos) {
                System.out.println(alumno);
            }
        }
    }

    // Método para listar los alumnos aprobados
    public void listarAprobados() {
        System.out.println("Alumnos aprobados:");
        for (Alumno alumno : alumnos) {
            if (alumno.isAprobado()) {
                System.out.println(alumno);
            }
        }
    }

    // Método para listar los alumnos suspendidos
    public void listarSuspendidos() {
        System.out.println("Alumnos suspendidos:");
        for (Alumno alumno : alumnos) {
            if (!alumno.isAprobado()) {
                System.out.println(alumno);
            }
        }
    }

    // Método para guardar los datos de los alumnos en un fichero binario
    public void guardarEnFichero(String nombreFichero) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreFichero))) {
            oos.writeObject(this.alumnos);
            System.out.println("Datos guardados correctamente en " + nombreFichero);
        } catch (IOException e) {
            System.out.println("Error al guardar los datos: " + e.getMessage());
        }
    }

    // Método para cargar los datos de los alumnos desde un fichero binario
    @SuppressWarnings("unchecked")
    public void cargarDesdeFichero(String nombreFichero) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreFichero))) {
            this.alumnos = (List<Alumno>) ois.readObject();
            System.out.println("Datos cargados correctamente desde " + nombreFichero);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos: " + e.getMessage());
        }
    }
}

