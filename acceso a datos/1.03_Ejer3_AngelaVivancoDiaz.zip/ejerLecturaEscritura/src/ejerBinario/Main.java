package ejerBinario;

import java.util.ArrayList;
import java.util.List;

//Clase principal para probar el sistema
public class Main {
    public static void main(String[] args) {
        GestionAlumnos gestion = new GestionAlumnos();

        // Insertar alumnos
        gestion.insertarAlumno("Juan", "Pérez", 8.5);
        gestion.insertarAlumno("Ana", "García", 4.0);
        gestion.insertarAlumno("Carlos", "López", 5.5);

        // Listar todos los alumnos
        System.out.println("Lista de alumnos antes de guardar:");
        gestion.listarAlumnos();

        // Guardar alumnos en un fichero binario
        gestion.guardarEnFichero("alumnos.bin");

        // Crear una nueva instancia de gestión de alumnos y cargar los datos desde el fichero binario
        GestionAlumnos nuevaGestion = new GestionAlumnos();
        nuevaGestion.cargarDesdeFichero("alumnos.bin");

        // Listar los alumnos cargados desde el fichero
        System.out.println("\nLista de alumnos después de cargar:");
        nuevaGestion.listarAlumnos();
    }
}