package ejerBinario;

import java.io.*;

public class Alumno extends Persona implements Serializable {
    private double nota;

    public Alumno(String nombre, String apellido, double nota) {
        super(nombre, apellido);
        this.nota = nota;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public boolean isAprobado() {
        return nota >= 5;
    }

    @Override
    public String toString() {
        return super.toString() + ", Nota: " + nota;
    }
}
