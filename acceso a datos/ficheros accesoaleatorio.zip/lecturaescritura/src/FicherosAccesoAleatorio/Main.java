package FicherosAccesoAleatorio;

import java.io.*;

public class Main {
	
	public static void EscrituraFicheroAleatorio(String fichero,String cadena,RandomAccessFile raf) {
		
		try {
		//abro el archivo para lectura y escritura
		raf= new RandomAccessFile(fichero,"rw");
		
		//Tamaño del fichero 
		long size = raf.length();
		
		//Me posiciono en el fichero con seek raf.seek(size) escribe al final podemos poner un valor segun donde queremos que escriba
		raf.seek(12);
		
		//escribir en el fichero
		raf.writeBytes(cadena);
		System.out.println("Se ha escrito en el fichero");
		raf.close();
		
		}catch(FileNotFoundException e) {
			
			System.out.println("ERROR: no se encuentra el fichero");
			System.out.println(e.getMessage());
			
		}catch(IOException e) {
			
			System.out.println("ERROR: en la lectura o escritura del fichero");
			System.out.println(e.getMessage());	
		}
	}
	
	public static void LecturaFicheroAleatorio( String fichero, long posicion, int longitud) {
		
		String resultado;
		
		try (RandomAccessFile raf =new RandomAccessFile(fichero,"r")) {
			raf.seek(posicion);
			//recuperamos array de bytes
			byte[] bytes = new byte[(int)raf.length()];//[(int)raf.length()] nos devuelve todos los caracteres mientras que longitud lee bloques
			//que queremos que lea
			raf.readFully(bytes);
			//los convertimos en string
			resultado = new String(bytes).trim();
			System.out.println(resultado);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		String fichero ="FicheroAccesoAleatorio.txt";
		String cadena = "****";
		
		//definir primer fichero
		RandomAccessFile raf = null;
		EscrituraFicheroAleatorio( fichero, cadena, raf);
		LecturaFicheroAleatorio( fichero, 0 ,50); //la longitud lee a bloque
		

	}

}
