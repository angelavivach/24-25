package pfinal;

import java.io.*;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Main {
    private static Administrador administrador = new Administrador();
    private static ArrayList<Cliente> clientes = new ArrayList<>();
    private static ArrayList<Gasolinera> gasolineras = new ArrayList<>();

    public static void main(String[] args) {
        // Cargar las gasolineras desde el archivo binario
        gasolineras = Gasolinera.cargarGasolineras();

        // Cargar los datos de los clientes desde el archivo XML
        cargarClientesDesdeXML("src/clientes.xml");

        // Crear las carpetas necesarias
        crearCarpetas();

        // Menú de opciones
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer

            switch (opcion) {
                case 1:
                    mostrarClientes();
                    break;
                case 2:
                    mostrarGasolineras();
                    break;
                case 3:
                    realizarVenta(scanner);
                    break;
                case 4:
                    administradorMenu(scanner);
                    break;
                case 5:
                    System.out.println("¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 5);

        // Al salir del programa, guardar las gasolineras en el archivo binario
        Gasolinera.guardarGasolineras(gasolineras);

        scanner.close();
    }

    // Mostrar menú principal
    private static void mostrarMenu() {
        System.out.println("\n--- Menú Principal ---");
        System.out.println("1. Ver todos los clientes");
        System.out.println("2. Ver gasolineras");
        System.out.println("3. Realizar venta (repostaje)");
        System.out.println("4. Administrador");
        System.out.println("5. Salir");
        System.out.print("Elige una opción: ");
    }

    // Cargar clientes desde archivo XML
    private static void cargarClientesDesdeXML(String archivoXML) {
        try {
            // Crear un DocumentBuilderFactory y un DocumentBuilder
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            
            // Leer el archivo XML
            File archivo = new File(archivoXML);
            Document document = builder.parse(archivo);
            
            // Normalizar el documento XML
            document.getDocumentElement().normalize();
            
            // Obtener la lista de nodos "cliente"
            NodeList listaClientes = document.getElementsByTagName("cliente");
            
            for (int i = 0; i < listaClientes.getLength(); i++) {
                Node nodo = listaClientes.item(i);
                
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) nodo;
                    
                    // Obtener los datos del cliente
                    int numeroCliente = Integer.parseInt(getTagValue("numeroCliente", elemento));
                    String nombre = getTagValue("nombre", elemento);
                    String direccion = getTagValue("direccion", elemento);
                    
                    // Crear un nuevo objeto Cliente y agregarlo a la lista
                    Cliente cliente = new Cliente(numeroCliente, nombre, direccion);
                    clientes.add(cliente);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método auxiliar para obtener el valor de una etiqueta en el XML
    private static String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag);
        if (nodeList != null && nodeList.getLength() > 0) {
            Node node = nodeList.item(0);
            return node.getTextContent();
        }
        return "";
    }

    // Crear las carpetas necesarias
    private static void crearCarpetas() {
        File ticketsDir = new File("TICKETS");
        if (!ticketsDir.exists()) ticketsDir.mkdir();
        
        File clientesDir = new File("clientes");
        if (!clientesDir.exists()) clientesDir.mkdir();
        
        File clientesAntiguosDir = new File("clientesAntiguos");
        if (!clientesAntiguosDir.exists()) clientesAntiguosDir.mkdir();
    }

    // Mostrar todos los clientes
    private static void mostrarClientes() {
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes disponibles.");
            return;
        }
        System.out.println("\n--- Clientes ---");
        for (Cliente cliente : clientes) {
            System.out.println("Número de Cliente: " + cliente.getNumeroCliente() + " | Nombre: " + cliente.getNombre());
        }
    }

    // Mostrar todas las gasolineras
    private static void mostrarGasolineras() {
        if (gasolineras.isEmpty()) {
            System.out.println("No hay gasolineras disponibles.");
            return;
        }
        System.out.println("\n--- Gasolineras ---");
        for (Gasolinera gasolinera : gasolineras) {
            gasolinera.mostrarInfo();
            System.out.println("--------------------------");
        }
    }

    // Realizar una venta (repostaje)
    private static void realizarVenta(Scanner scanner) {
        System.out.print("Introduce tu número de cliente: ");
        int numeroCliente = scanner.nextInt();
        scanner.nextLine();  // Limpiar buffer
        Cliente cliente = encontrarCliente(numeroCliente);
        
        if (cliente == null) {
            System.out.println("Cliente no encontrado.");
            return;
        }

        System.out.println("\n--- Gasolineras Disponibles ---");
        for (int i = 0; i < gasolineras.size(); i++) {
            System.out.println(i + 1 + ". " + gasolineras.get(i).getNombre() + " | Ubicación: " + gasolineras.get(i).getUbicacion());
        }

        System.out.print("Selecciona la gasolinera (número): ");
        int seleccion = scanner.nextInt();
        scanner.nextLine();  // Limpiar buffer
        Gasolinera gasolinera = gasolineras.get(seleccion - 1);

        System.out.print("¿Qué tipo de combustible deseas? (Gasolina95 / Diesel): ");
        String tipoCombustible = scanner.nextLine();
        System.out.print("¿Cuántos litros deseas repostar?: ");
        int cantidad = scanner.nextInt();

        if (gasolinera.repostar(tipoCombustible, cantidad)) {
            Ticket ticket = new Ticket(cliente, gasolinera, tipoCombustible, cantidad);
            System.out.println("\n--- Ticket Generado ---");
            System.out.println("Número de Ticket: " + ticket);
        } else {
            System.out.println("No hay suficiente stock de " + tipoCombustible + " en la gasolinera.");
        }
    }

    // Buscar un cliente por número
    private static Cliente encontrarCliente(int numeroCliente) {
        for (Cliente cliente : clientes) {
            if (cliente.getNumeroCliente() == numeroCliente) {
                return cliente;
            }
        }
        return null;
    }

    // Menú del Administrador
    private static void administradorMenu(Scanner scanner) {
        int opcion;
        do {
            System.out.println("\n--- Menú Administrador ---");
            System.out.println("1. Ver clientes");
            System.out.println("2. Añadir cliente");
            System.out.println("3. Eliminar cliente");
            System.out.println("4. Ver gasolineras");
            System.out.println("5. Añadir gasolinera");
            System.out.println("6. Volver al menú principal");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar buffer

            switch (opcion) {
                case 1:
                    mostrarClientes();
                    break;
                case 2:
                    añadirCliente(scanner);
                    break;
                case 3:
                    eliminarCliente(scanner);
                    break;
                case 4:
                    mostrarGasolineras();
                    break;
                case 5:
                    añadirGasolinera(scanner);
                    break;
                case 6:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 6);
    }

    // Añadir un nuevo cliente
    private static void añadirCliente(Scanner scanner) {
        System.out.print("Introduce el número de cliente: ");
        int numeroCliente = scanner.nextInt();
        scanner.nextLine();  // Limpiar buffer
        System.out.print("Introduce el nombre del cliente: ");
        String nombre = scanner.nextLine();
        System.out.print("Introduce la dirección del cliente: ");
        String direccion = scanner.nextLine();
        
        Cliente cliente = new Cliente(numeroCliente, nombre, direccion);
        clientes.add(cliente);
        System.out.println("Cliente añadido correctamente.");
    }

    // Eliminar un cliente
    private static void eliminarCliente(Scanner scanner) {
        System.out.print("Introduce el número de cliente a eliminar: ");
        int numeroCliente = scanner.nextInt();
        scanner.nextLine();  // Limpiar buffer
        
        Cliente cliente = encontrarCliente(numeroCliente);
        
        if (cliente != null) {
            clientes.remove(cliente);
            System.out.println("Cliente eliminado correctamente.");
        } else {
            System.out.println("Cliente no encontrado.");
        }
    }

    // Añadir una nueva gasolinera
    private static void añadirGasolinera(Scanner scanner) {
        System.out.print("Introduce el nombre de la gasolinera: ");
        String nombre = scanner.nextLine();
        System.out.print("Introduce la ubicación de la gasolinera: ");
        String ubicacion = scanner.nextLine();
        System.out.print("Introduce los litros de Gasolina 95 disponibles: ");
        int litrosGasolina95 = scanner.nextInt();
        System.out.print("Introduce los litros de Diesel disponibles: ");
        int litrosDiesel = scanner.nextInt();
        System.out.print("Introduce el precio de Gasolina 95: ");
        double precioGasolina95 = scanner.nextDouble();
        System.out.print("Introduce el precio de Diesel: ");
        double precioDiesel = scanner.nextDouble();
        
        Gasolinera gasolinera = new Gasolinera(nombre, ubicacion, litrosGasolina95, litrosDiesel, precioGasolina95, precioDiesel);
        gasolineras.addAll(gasolineras);
        System.out.println("Gasolinera añadida correctamente.");
    }
}
