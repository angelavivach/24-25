package pfinal;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.File;

public class Cliente implements Serializable {
    private int numeroCliente;
    private String nombre;
    private String direccion;

    public Cliente(int numeroCliente, String nombre, String direccion) {
        this.numeroCliente = numeroCliente;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public int getNumeroCliente() {
        return numeroCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void guardarFicha() {
        // Guardar la ficha del cliente como un archivo de texto
        String nombreArchivo = numeroCliente + ".txt";
        try (PrintWriter writer = new PrintWriter(new File(nombreArchivo))) {
            writer.println("Número de cliente: " + numeroCliente);
            writer.println("Nombre: " + nombre);
            writer.println("Dirección: " + direccion);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

