package pfinal;

import java.io.File;
import java.util.ArrayList;

public class Administrador {

    private ArrayList<Cliente> clientes;
    private ArrayList<Gasolinera> gasolineras;

    public Administrador() {
        this.clientes = new ArrayList<>();
        this.gasolineras = new ArrayList<>();
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
        cliente.guardarFicha();
    }

    public void eliminarCliente(Cliente cliente) {
        clientes.remove(cliente);
        File clienteFile = new File(cliente.getNumeroCliente() + ".txt");
        clienteFile.renameTo(new File("clientesAntiguos/" + cliente.getNumeroCliente() + ".txt"));
    }

    public void verClientes() {
        for (Cliente cliente : clientes) {
            System.out.println(cliente.getNombre() + " - " + cliente.getDireccion());
        }
    }

    public void verGasolineras() {
        for (Gasolinera gasolinera : gasolineras) {
            gasolinera.mostrarInfo();
        }
    }

    public void agregarGasolinera(Gasolinera gasolinera) {
        gasolineras.addAll(gasolineras);
    }
}

