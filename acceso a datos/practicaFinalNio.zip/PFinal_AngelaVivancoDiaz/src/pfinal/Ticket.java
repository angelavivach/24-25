package pfinal;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class Ticket {
    private static int numeroTicket = 1;
    private Cliente cliente;
    private Gasolinera gasolinera;
    private String tipoCombustible;
    private int cantidad;
    private double total;

    public Ticket(Cliente cliente, Gasolinera gasolinera, String tipoCombustible, int cantidad) {
        this.cliente = cliente;
        this.gasolinera = gasolinera;
        this.tipoCombustible = tipoCombustible;
        this.cantidad = cantidad;
        if (tipoCombustible.equals("Gasolina95")) {
            this.total = cantidad * gasolinera.getPrecioGasolina95();
        } else {
            this.total = cantidad * gasolinera.getPrecioDiesel();
        }
        generarTicket();
    }

    private void generarTicket() {
        // Crear un archivo de ticket con los datos
        String nombreArchivo = "TICKETS/" + numeroTicket + ".txt";
        try (PrintWriter writer = new PrintWriter(new File(nombreArchivo))) {
            writer.println("Número de Ticket: " + numeroTicket);
            writer.println("Cliente: " + cliente.getNombre());
            writer.println("Gasolinera: " + gasolinera.getNombre());
            writer.println("Ubicación: " + gasolinera.getUbicacion());
            writer.println(tipoCombustible + " (" + (tipoCombustible.equals("Gasolina95") ? gasolinera.getPrecioGasolina95() : gasolinera.getPrecioDiesel()) + ")-------" + cantidad);
            writer.println("Total: " + total + " Euros");
        } catch (IOException e) {
            e.printStackTrace();
        }

        numeroTicket++;
    }
}

