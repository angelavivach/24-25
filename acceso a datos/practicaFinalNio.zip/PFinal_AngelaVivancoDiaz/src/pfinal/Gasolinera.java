package pfinal;


import java.io.*;
import java.util.ArrayList;

public class Gasolinera implements Serializable {
    private String nombre;
    private String ubicacion;
    private int litrosGasolina95;
    private int litrosDiesel;
    private double precioGasolina95;
    private double precioDiesel;

    // Constructor
    public Gasolinera(String nombre, String ubicacion, int litrosGasolina95, int litrosDiesel, 
                      double precioGasolina95, double precioDiesel) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.litrosGasolina95 = litrosGasolina95;
        this.litrosDiesel = litrosDiesel;
        this.precioGasolina95 = precioGasolina95;
        this.precioDiesel = precioDiesel;
    }

    // Métodos getters
    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public int getLitrosGasolina95() {
        return litrosGasolina95;
    }

    public int getLitrosDiesel() {
        return litrosDiesel;
    }

    public double getPrecioGasolina95() {
        return precioGasolina95;
    }

    public double getPrecioDiesel() {
        return precioDiesel;
    }

    // Método para repostar
    public boolean repostar(String tipoCombustible, int cantidad) {
        if (tipoCombustible.equalsIgnoreCase("Gasolina95")) {
            if (litrosGasolina95 >= cantidad) {
                litrosGasolina95 -= cantidad;  // Reducir los litros de gasolina disponibles
                return true;
            } else {
                return false;  // No hay suficiente gasolina disponible
            }
        } else if (tipoCombustible.equalsIgnoreCase("Diesel")) {
            if (litrosDiesel >= cantidad) {
                litrosDiesel -= cantidad;  // Reducir los litros de diésel disponibles
                return true;
            } else {
                return false;  // No hay suficiente diésel disponible
            }
        } else {
            return false;  // Tipo de combustible no válido
        }
    }

    // Método para mostrar la información de la gasolinera
    public void mostrarInfo() {
        System.out.println("Gasolinera: " + nombre);
        System.out.println("Ubicación: " + ubicacion);
        System.out.println("Gasolina 95: " + litrosGasolina95 + " litros disponibles");
        System.out.println("Diesel: " + litrosDiesel + " litros disponibles");
        System.out.println("Precio Gasolina 95: " + precioGasolina95 + " €/litro");
        System.out.println("Precio Diesel: " + precioDiesel + " €/litro");
    }

    // Método para guardar todas las gasolineras en un archivo binario
    public static void guardarGasolineras(ArrayList<Gasolinera> gasolineras) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("src/gasolineras.bin"))) {
            oos.writeObject(gasolineras);  // Escribir la lista de gasolineras
            System.out.println("Gasolineras guardadas correctamente en gasolineras.bin.");
        } catch (IOException e) {
            System.out.println("Error al guardar las gasolineras: " + e.getMessage());
        }
    }

    // Método para cargar las gasolineras desde el archivo binario
    public static ArrayList<Gasolinera> cargarGasolineras() {
        ArrayList<Gasolinera> gasolineras = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("gasolineras.bin"))) {
            gasolineras = (ArrayList<Gasolinera>) ois.readObject();
            System.out.println("Gasolineras cargadas correctamente.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar las gasolineras: " + e.getMessage());
        }
        return gasolineras;
    }
}

