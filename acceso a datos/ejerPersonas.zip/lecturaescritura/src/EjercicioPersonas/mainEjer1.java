package EjercicioPersonas;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class mainEjer1 {
	public static void escribirPersonas(List <Persona> persona, String ruta) {
		try {
			//creo descriptor de fichero de 0
			File fichero=new File(ruta);
			//Indico que abro el fichero para escribir
			FileOutputStream escritura= new FileOutputStream(fichero);
			//Indico que voy a escribir objetos
			ObjectOutputStream oos =new ObjectOutputStream(escritura);
			
			
			
			oos.writeObject(persona);
			System.out.println("Las personas han sido guardadas");
			oos.close();
			
		}catch(FileNotFoundException e) { 
			e.printStackTrace();
		}catch(IOException e ) { 
			e.getStackTrace();
		}
	}
	
	public static List <Persona>  leerPersonas(String ruta) {
		List <Persona> persona= new ArrayList<>();
		
		try {
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File(ruta)));
			persona = (List <Persona>)ois.readObject();

			ois.close();
			
		}catch(ClassNotFoundException  e) { //porque necesito que me devuelva un error la clase
			e.getMessage();
		}catch(IOException e ) { 
			e.getStackTrace();
		}
		return persona;
	}
	
	public static void main(String[] args) {
		String ruta ="ejer1.bin";
		String nombre="";
		int opcion=1;
		int edad;
		
		List <Persona> persona= new ArrayList<>();
		Scanner sc= new Scanner(System.in);
		System.out.println("Introduce los datos de las personas");
		
		
		while(opcion!=0) {
			System.out.println("Introduce un nombre");
			nombre=sc.nextLine();
			System.out.println("Introduce una edad");
			edad=sc.nextInt();
			
			/*Persona personaX = new Persona(nombre,edad);
			persona.add(personaX);
			*/
			
			persona.add(new Persona(nombre,edad));
			
			System.out.println("¿Quieres continuar? Pulsa 0 en cado de no ");
			opcion=sc.nextInt();
			}
	    	//Hacemos la llamada para escribir el array en el fichero

		escribirPersonas(persona,ruta);
		List <Persona> personasLeidas = leerPersonas(ruta);
		for (Persona p:personasLeidas) {
			System.out.println(p);
		}
		sc.close();

	}

}
