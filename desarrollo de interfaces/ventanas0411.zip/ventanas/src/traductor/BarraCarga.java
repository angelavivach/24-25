package traductor;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.Timer;
import java.awt.BorderLayout;

public class BarraCarga {
    private Image imagenFondo;
    private JFrame frame;
    private Timer crono; 
    private JProgressBar progressBar; // Barra de progreso
    private int variable = 5; // Cambiar SOLO este valor para el contador
    private int i = variable; // NO TOCAR

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                BarraCarga window = new BarraCarga();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public BarraCarga() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        panel.setLayout(null);
        
        progressBar = new JProgressBar(0, variable); // Inicializar con rango
        progressBar.setStringPainted(true);
        progressBar.setBounds(98, 154, 225, 23);
        panel.add(progressBar);
        
        JLabel lblNewLabel = new JLabel(String.valueOf(variable));
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel.setBounds(232, 98, 115, 23);
        panel.add(lblNewLabel);
        
        JButton btnNewButton = new JButton("Start");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnNewButton.setBounds(98, 100, 89, 23);
        panel.add(btnNewButton);
        
        JPanel panel_1 = createPanelConFondo();
        panel_1.setBounds(0, 0, 434, 261);
        panel.add(panel_1);
        panel_1.setVisible(false);
        
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                i = variable;
                lblNewLabel.setText(String.valueOf(i));
                progressBar.setValue(0); // Reiniciar la barra de progreso
                crono.start();
                panel_1.setVisible(false);
            }
        });

        crono = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                i--;
                lblNewLabel.setText(String.valueOf(i));
                progressBar.setValue(variable - i); // Actualizar la barra de progreso

                if (i <= 0) {
                    crono.stop();
                    lblNewLabel.setVisible(false);
                    progressBar.setVisible(false);
                    btnNewButton.setVisible(false);
                    cargarImagen();
                    panel_1.setVisible(true);
                }
            }   
        });
    }

    private void cargarImagen() {
        try {
            imagenFondo = ImageIO.read(new File("src/aguacate.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JPanel createPanelConFondo() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagenFondo != null) {
                    g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), null);
                }
            }
        };
    }
}
