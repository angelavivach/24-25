package traductor;

import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class ImagenFondo {
    private JFrame frame;
    private Image imagenFondo;
    private int indiceImagenActual = 0;

    // Rutas de las imágenes
    private final String imagen1 = "src/traductor/gato.jpg";
    private final String imagen2 = "src/aguacate.png";

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ImagenFondo window = new ImagenFondo();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ImagenFondo() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Cambio de Fondo");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Cargar la imagen inicial
        cargarImagen();

        // Configurar el panel con fondo
        frame.getContentPane().add(createPanelConFondo());

        // Configurar el menú
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Opciones");
        JMenuItem menuItem = new JMenuItem("Cambiar fondo");
        menuItem.addActionListener(e -> cambiarFondo());
        menu.add(menuItem);
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);
    }

    private void cargarImagen() {
        try {
            if (indiceImagenActual % 2 == 0) {
                imagenFondo = ImageIO.read(new File(imagen1));
            } else {
                imagenFondo = ImageIO.read(new File(imagen2));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cambiarFondo() {
        indiceImagenActual++;
        cargarImagen();
        frame.getContentPane().repaint(); // Actualiza el panel
    }

    private JPanel createPanelConFondo() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagenFondo != null) {
                    g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), null);
                }
            }
        };
    }
}
