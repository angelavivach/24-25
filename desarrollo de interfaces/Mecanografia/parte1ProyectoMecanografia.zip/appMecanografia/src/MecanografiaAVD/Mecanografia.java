package MecanografiaAVD;

import javax.swing.*;
import java.awt.*;

public class Mecanografia {

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
            	PantallaInicio PantallaInicio = new PantallaInicio();
            	PantallaInicio.mostrar();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
