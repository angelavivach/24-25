package MecanografiaAVD;

import javax.swing.*;
import java.awt.*;

public class VentanaLogin {

    private JFrame loginFrame;

    public VentanaLogin() {
        initialize();
    }

    private void initialize() {
        loginFrame = new JFrame("Curso Mecanografia");
        loginFrame.setIconImage(Toolkit.getDefaultToolkit().getImage("fotos\\icono.png"));
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(400, 300);
        loginFrame.setMinimumSize(new Dimension(300, 200)); // Tamaño mínimo para evitar una compresión excesiva
        loginFrame.setLocationRelativeTo(null);
        
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout()); // Configurar GridBagLayout para redimensionamiento
        loginFrame.getContentPane().add(loginPanel);
        
        placeLoginComponents(loginPanel);
    }

    public void mostrar() {
        loginFrame.setVisible(true);
    }

    private void placeLoginComponents(JPanel panel) {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL; // Extender los componentes horizontalmente
        
        // Etiqueta para el título
        JLabel titleLabel = new JLabel("Iniciar Sesión");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2; // Ocupa dos columnas
        constraints.insets = new Insets(10, 10, 10, 10);
        panel.add(titleLabel, constraints);
        
        // Etiqueta de usuario
        JLabel userLabel = new JLabel("Usuario:");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        panel.add(userLabel, constraints);

        // Campo de texto de usuario
        JTextField userText = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridy = 1;
        panel.add(userText, constraints);

        // Etiqueta de contraseña
        JLabel passwordLabel = new JLabel("Contraseña:");
        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(passwordLabel, constraints);

        // Campo de texto de contraseña
        JPasswordField passwordText = new JPasswordField(20);
        constraints.gridx = 1;
        constraints.gridy = 2;
        panel.add(passwordText, constraints);

        // Botón de login
        JButton loginButton = new JButton("Iniciar sesión");
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.insets = new Insets(10, 10, 10, 10);
        panel.add(loginButton, constraints);
    }
}


