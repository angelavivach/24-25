package MecanografiaAVD;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class PantallaInicio {

    private JFrame frame;
    private JProgressBar progressBar;
    private JLabel backgroundLabel;
    private boolean filesAreValid = false;

    public PantallaInicio() {
        initialize();
    }

    private void initialize() {
        // Crear el marco sin borde
        frame = new JFrame();
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage("fotos/icono.png"));
        frame.setSize(600, 400);
        frame.setUndecorated(true); // Quitar el borde
        frame.setLocationRelativeTo(null); // Centrar en pantalla
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear una etiqueta para la imagen de fondo
        backgroundLabel = new JLabel(new ImageIcon("fotos/1.jpg"));
        backgroundLabel.setLayout(new BorderLayout());
        frame.setContentPane(backgroundLabel);

        // Crear y configurar la barra de progreso
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        backgroundLabel.add(progressBar, BorderLayout.SOUTH);

        // Iniciar la barra de carga y comprobar archivos
        startLoading();
    }

    public void mostrar() {
        frame.setVisible(true);
    }

    private void startLoading() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            int progress = 0;

            @Override
            public void run() {
                progress += 20; // Incremento de la barra de carga cada segundo
                progressBar.setValue(progress);

                // Comprobar archivos después de 4 segundos (80% de progreso)
                if (progress == 80) {
                    filesAreValid = checkFiles();
                    if (!filesAreValid) {
                        JOptionPane.showMessageDialog(frame, "Error: Faltan archivos necesarios para ejecutar la aplicación.");
                        System.exit(0);
                    }
                }

                // Si el progreso llega al 100%, pasar a la ventana de Login
                if (progress >= 100) {
                    timer.cancel();
                    abrirVentanaLogin();
                }
            }
        }, 0, 1000); // Actualiza cada segundo
    }

    private boolean checkFiles() {
        // Verificar que existan tres archivos en la ruta especificada
        String[] archivos = {"archivos/Usuarios.txt", "archivos/Textos.txt", "archivos/Estadisticas.txt"};
        for (String ruta : archivos) {
            File archivo = new File(ruta);
            if (!archivo.exists()) {
                return false;
            }
        }
        return true;
    }

    private void abrirVentanaLogin() {
        frame.dispose(); // Cerrar la pantalla de carga
        VentanaLogin login = new VentanaLogin();
        login.mostrar();
    }
}

