package ejer2;

public class imprimible {
	void imprimir();

}
