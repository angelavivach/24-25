package ejer1;

public class animal {

	 public void hacerSonido() {
	        System.out.println("Sonido de animal");
	    }
	}


