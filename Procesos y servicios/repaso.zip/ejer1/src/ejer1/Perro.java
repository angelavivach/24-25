package ejer1;

public class Perro extends animal {
    @Override
    public void hacerSonido() {
        System.out.println("Guau!");
    }
}


