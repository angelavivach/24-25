package ejer3Hilos.ejer2RobotParalelo;

public class RobotExplorador extends Robot implements Runnable {
    public RobotExplorador(String nombre, int tiempoOperacion) {
        super(nombre, tiempoOperacion);
    }

    @Override
    public void operar() {
        System.out.println(nombre + " ha comenzado a explorar su área asignada.");
        try {
            Thread.sleep(tiempoOperacion * 1000); // Convertir a milisegundos
        } catch (InterruptedException e) {
            System.out.println(nombre + " fue interrumpido durante la exploración.");
        }
        System.out.println(nombre + " ha terminado de explorar su área.");
    }

    @Override
    public void run() {
        operar();
    }
}
