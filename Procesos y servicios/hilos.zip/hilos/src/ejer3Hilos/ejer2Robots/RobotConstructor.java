package ejer3Hilos.ejer2Robots;

public class RobotConstructor extends Robot{
	private static int estructurasConstruidas = 0;

    public RobotConstructor(String nombre, int tiempoOperacion) {
        super(nombre, tiempoOperacion);
    }

    public synchronized void construir() {
        estructurasConstruidas += 3;
        System.out.println(nombre + " ha construido 3 estructuras. Total: " + estructurasConstruidas);
    }

    public synchronized void destruir() {
        if (estructurasConstruidas > 0) {
            estructurasConstruidas -= 1;
            System.out.println(nombre + " ha destruido 1 estructura. Total: " + estructurasConstruidas);
        }
    }

    @Override
    public void operar() {
        for (int i = 0; i < 10; i++) {
            if (estructurasConstruidas % 2 == 0) {
                construir();
            } else {
                destruir();
            }
            try {
                Thread.sleep(tiempoOperacion * 1000); // Simula tiempo de operación
            } catch (InterruptedException e) {
                System.out.println(nombre + " fue interrumpido durante la operación.");
            }
        }
    }

	public static int getEstructurasConstruidas() {
		// TODO Auto-generated method stub
		return estructurasConstruidas;
	}
}
