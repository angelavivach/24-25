package ejer3Hilos.ejer3Hilos;

public class ejer1RobotExplorador extends Thread{
          private String nombre;
          private int tiempoExploracion;
          
          public ejer1RobotExplorador(String nombre, int tiempoExploracion) {
			this.nombre=nombre;
			this.tiempoExploracion=tiempoExploracion;
		}

		public void run() {
  	      this.explorar();
  	    }
		
		public void explorar() {
			try {
	            	System.out.println(nombre+ " ha comenzado la exploración");
	            	 Thread.sleep(tiempoExploracion * 1000);
	       	         System.out.println(nombre + " ha terminado de explorar ");
	            } catch (InterruptedException e) {
	                System.out.println(nombre + " ha sido interrumpido.");
	                
	            }
		 }
          
          public static void main(String[] args) {
  	        
        	  ejer1RobotExplorador robot1 = new ejer1RobotExplorador("Suki",2);
        	  ejer1RobotExplorador robot2 = new ejer1RobotExplorador("Robostdreams",5);  
        	  ejer1RobotExplorador robot3 = new ejer1RobotExplorador("Terminaitor",7); 
        	  ejer1RobotExplorador robot4 = new ejer1RobotExplorador("Bumbelby",6);  
  	        
        	  robot1.start();
        	  robot2.start();
        	  robot3.start();
        	  robot4.start();
  	    }
}
