package ejerCondicionesCarrera;

import java.util.ArrayList;
import java.util.List;

class AgregarPedido implements Runnable {
    private ProcesadorDePedidos procesador;

    public AgregarPedido(ProcesadorDePedidos procesador) {
        this.procesador = procesador;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 20; i++) {
            procesador.agregarPedido("Pedido " + i);
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


class ProcesarPedido implements Runnable {
    private ProcesadorDePedidos procesador;

    public ProcesarPedido(ProcesadorDePedidos procesador) {
        this.procesador = procesador;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 20; i++) {
            procesador.procesarPedido();
            try {
                Thread.sleep(70);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


public class ProcesadorDePedidos {
    private List<String> pedidos = new ArrayList<>();
    
	/*
	 * Como esta clase solo tiene variable metodo y pedidos que la utilizan 
	 * y la seccion critiva de cada  metodo es el metodo entero, synchronized al metodo es la solucion valida.
	 *( Si tueviera tambien un array de clientes tendria que crear dos locks uno para clientes y otro para pedidos )
	 * 
	 * Lo unico que seguira pasando que se quedan sin procesar pedidos.Esto no es un problema de concurrencia.Si lo fuera podria pasarnos tambien.
	 * Dependiendo de los tiempos,podrian quedarse pedidos sin procesar
	 *
	 */

    public synchronized void agregarPedido(String pedido) {
    
        pedidos.add(pedido);
        System.out.println("Pedido agregado: " + pedido);
    	
    }

    public synchronized void procesarPedido() {
    	
        if (!pedidos.isEmpty()) {
            String pedido = pedidos.remove(0);
            System.out.println("Pedido procesado: " + pedido);
        } else {
        	//En lugar de solo print, tambien le decimos que espere a que lleguen los pedidos, la espera es variable.
            System.out.println("No hay pedidos para procesar.");
        }
    	
    }
    
    public static void main(String[] args) {
        ProcesadorDePedidos procesador = new ProcesadorDePedidos();

        Thread hiloAgregar = new Thread(new AgregarPedido(procesador));
        Thread hiloProcesar = new Thread(new ProcesarPedido(procesador));

        hiloAgregar.start();
        hiloProcesar.start();

        try {
            hiloAgregar.join();
            hiloProcesar.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
