package hilos.Ejemplo1.problemasConcurrencia;

import hilos.Ejemplo1.RatonRunnable;

public class RatonConProblemas implements Runnable{

	private String nombre;
	private int tiempoAlimentacion;
	private static int alimentoConsumido=0;
	
	public RatonConProblemas(String nombre, int tiempoAlimentacion) {
		this.nombre= nombre;
		this.tiempoAlimentacion = tiempoAlimentacion;
	}

    
	@Override // Se auto genera porque la inteface te obliga a implementar
	public void run() {
		this.comer();
	}
	
	 public void comer() {
		 try {
				System.out.printf("El ratón %s ha comenzado a alimentarse\n",nombre);
				Thread.sleep(tiempoAlimentacion*1000);
				alimentoConsumido++;//hay que sincronizar esto porque puede dar lugar a condiciones de carrera
				System.out.printf("El ratón %s ha terminado de alimentarse\n", nombre);	
				System.out.printf("Alimento consumido %d\n", alimentoConsumido);	
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	 }
	 
	public static void main(String[] args) {
        RatonConProblemas Alba = new RatonConProblemas("Alba",4);
		
		for	(int i=0; i<1000;i++) {
			new Thread(Alba).start();	
		}

	}

}
