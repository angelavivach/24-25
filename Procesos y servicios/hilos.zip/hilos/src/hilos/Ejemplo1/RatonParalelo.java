package hilos.Ejemplo1;

/**
 * Con thread no puedes heredar de otras (porque java no admite herencia multiple). Lo que hay son interfaces.
 * Ejemplos de interfaces Runnable y Callable 
 *  Notas: otros lenguajes de programacion si lo permiten como c++
 */
public class RatonParalelo extends Thread{
	private String nombre;
	private int tiempoAlimentacion;
	
	public RatonParalelo(String nombre, int tiempoAlimentacion) {
		super();
		this.nombre= nombre;
		this.tiempoAlimentacion = tiempoAlimentacion;
	}


	@Override //Es metodo de la clase thread
	public void run() {
		//Esto es lo que se va a paralelizar
		this.comer();
	}
	 public void comer() {
		 try {
				System.out.printf("El ratón %s ha comenzado a alimentarse\n",nombre);
				Thread.sleep(tiempoAlimentacion*1000);
				System.out.printf("El ratón %s ha terminado de alimentarse\n", nombre);			
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	 }
	public static void main(String[] args) {
		RatonParalelo Alba = new RatonParalelo("Alba",4);
		RatonParalelo David = new RatonParalelo("David",5);
		RatonParalelo Fernando = new RatonParalelo("Fernando",3);
		RatonParalelo Dani = new RatonParalelo("Dani",7);
		
        //.run() es para ejecutar secuencialmente por eso nosotros usaremos start.
		//start() que es para que inicie el hilo de nuevo, start es lo que crea el hilo.
		Alba.start();
		David.start();
		Fernando.start();
		Dani.start();
		
		//Te los va a mostrar en cualquier orden porque puede ser diferente segun si estan preparados para ejecutarse

	}

}
