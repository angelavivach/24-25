package hilos.Ejemplo1;

public class RatonSecuencial {
	private static final String Systemctl = null;
	private String nombre;
	private int tiempoAlimentacion;
	
	public RatonSecuencial(String nombre, int tiempoAlimentacion) {
		super();
		this.nombre= nombre;
		this.tiempoAlimentacion = tiempoAlimentacion;
	}
	
	public void comer() {
		try {
			System.out.printf("El ratón %s ha comenzado a alimentarse\n",nombre);
			Thread.sleep(tiempoAlimentacion*1000);
			System.out.printf("El ratón %s ha terminado de alimentarse\n", nombre);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		RatonSecuencial Alba = new RatonSecuencial("Alba",4);
		RatonSecuencial David = new RatonSecuencial("David",5);
		RatonSecuencial Fernando = new RatonSecuencial("Fernando",3);
		RatonSecuencial Dani = new RatonSecuencial("Dani",7);
		

		Alba.comer();
		David.comer();
		Fernando.comer();
		Dani.comer();
	}

}
