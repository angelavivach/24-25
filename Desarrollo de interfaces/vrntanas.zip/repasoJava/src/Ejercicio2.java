
public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String cadena = "albornoz";
		 int entero = 10;
		 char caracter = '@';
		 double decimal = 9.5;
		 boolean condicion = true;
		 
		 System.out.println(cadena);
		 System.out.print(entero);
		 System.out.print(caracter);
		 System.out.println(decimal);
		 System.out.println(condicion);

	}

}
