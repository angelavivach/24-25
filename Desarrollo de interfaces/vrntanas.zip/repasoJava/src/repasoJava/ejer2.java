package repasoJava;

public class ejer2 {

	public static void main(String[] args) {
		String nombre ="Angela";
		int edad=20;
		char inicial='A';
		double altura=1.2;
		boolean registro= true;
		
		System.out.println("Nombre " + nombre);
		System.out.println("Edad " + edad);
		System.out.println("Inicial " + inicial);
		System.out.println("Altura " + altura);
		System.out.println("Esta registrado " + registro);

	}

}
