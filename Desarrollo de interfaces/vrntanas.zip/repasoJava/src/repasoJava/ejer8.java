package repasoJava;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class Modulo {
    private String nombre;
    private int horas;
    private String profesor;
    private boolean convalidable;

    // Constructor
    public Modulo(String nombre, int horas, String profesor, boolean convalidable) {
        this.nombre = nombre;
        this.horas = horas;
        this.profesor = profesor;
        this.convalidable = convalidable;
    }

    // Método para mostrar información del módulo
    public String toString() {
        return "Modulo: " + nombre + ", Horas: " + horas + ", Profesor: " + profesor + ", Convalidable: " + (convalidable ? "Sí" : "No");
    }
}

// Clase Alumno
class Alumno {
    private String dni;
    private String nombre;
    private String apellidos;
    private String fechaNacimiento;
    private String sexo;
    private boolean repetidor;
    private List<Modulo> modulos; //varios modulos
    //private Modulo unModdulo; //dato tipo modulo (solo uno)

    // Constructor
    public Alumno(String dni, String nombre, String apellidos, String fechaNacimiento, String sexo, boolean repetidor) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
        this.repetidor = repetidor;
        this.modulos = new ArrayList<>();
    }

    // Método para añadir un módulo
    public void matricularEnModulo(Modulo modulo) {
        this.modulos.add(modulo);
    }

    // Método para mostrar información del alumno y sus módulos
    public void mostrarInformacion() {
        System.out.println("DNI: " + dni);
        System.out.println("Nombre: " + nombre + " " + apellidos);
        System.out.println("Fecha de Nacimiento: " + fechaNacimiento);
        System.out.println("Sexo: " + sexo);
        System.out.println("Repetidor: " + (repetidor ? "Sí" : "No"));
        System.out.println("Módulos matriculados:");
        for (Modulo modulo : modulos) {
            System.out.println("  - " + modulo.toString());
        }
        System.out.println();
    }
}

public class ejer8 {
	
	// Clase principal
	
	    public static void main(String[] args) {
	        // Crear módulos
	        Modulo modulo1 = new Modulo("Matemáticas", 60, "Prof. García", false);
	        Modulo modulo2 = new Modulo("Lengua", 50, "Prof. Pérez", true);
	        Modulo modulo3 = new Modulo("Física", 70, "Prof. Rodríguez", false);
	        Modulo modulo4 = new Modulo("Historia", 45, "Prof. Sánchez", true);

	        // Crear alumnos
	        Alumno alumno1 = new Alumno("12345678A", "Juan", "López García", "15/04/2005", "Masculino", false);
	        Alumno alumno2 = new Alumno("87654321B", "Ana", "Martínez Pérez", "23/09/2004", "Femenino", true);

	        // Matricular alumnos en módulos
	        alumno1.matricularEnModulo(modulo1);
	        alumno1.matricularEnModulo(modulo2);

	        alumno2.matricularEnModulo(modulo3);
	        alumno2.matricularEnModulo(modulo4);

	        // Mostrar información de los alumnos
	        System.out.println("Información de los alumnos:");
	        System.out.println("----------------------------");
	        alumno1.mostrarInformacion();
	        System.out.println("----------------------------");
	        alumno2.mostrarInformacion();
	    
	}
}



