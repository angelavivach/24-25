package repasoJava;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ejer4 {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        // Solicitar al usuario el tamaño de la matriz (n x n)
        System.out.println("Introduce el tamaño de la matriz (n x n): ");
        int n = scanner.nextInt();
        
        // Crear la matriz de tamaño n x n
        int[][] matriz = new int[n][n];
        
        // Rellenar la matriz con números aleatorios y mostrarla
        System.out.println("Matriz generada:");
        int suma = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = random.nextInt(100); // Números aleatorios entre 0 y 99
                System.out.print(matriz[i][j] + "\t"); // Mostrar la matriz
                suma += matriz[i][j]; //suma 
            }
            System.out.println(); // Salto de línea entre filas
        }

        // Mostrar la suma de los elementos
        System.out.println("La suma de todos los elementos de la matriz es: " + suma);        
        
    }


}
