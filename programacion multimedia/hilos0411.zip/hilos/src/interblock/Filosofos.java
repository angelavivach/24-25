package interblock;

public class Filosofos {

}
