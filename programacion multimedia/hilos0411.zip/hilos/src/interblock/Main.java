package interblock;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class Archivo {
    private String nombre;

    public Archivo(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
    // Simulamos la escritura en archivo
    public void escribir(String mensaje) {
        System.out.println(Thread.currentThread().getName() + " escribió en " + nombre + ": " + mensaje);
    }
}

class TareaEscritura implements Runnable {
    private Archivo archivo1;
    private Archivo archivo2;
    private Archivo archivo3;

    public TareaEscritura(Archivo archivo1, Archivo archivo2, Archivo archivo3) {
        this.archivo1 = archivo1;
        this.archivo2 = archivo2;
        this.archivo3 = archivo3;
    }

    @Override
    public void run() {
        // Bloqueamos los archivos en un orden fijo para evitar el interbloqueo
        // Orden fijo: archivoA, archivoB, archivoC
   
        synchronized (archivo1) {
            System.out.println(Thread.currentThread().getName() + " bloqueó " + archivo1.getNombre());
            try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }

            synchronized (archivo2) {
                System.out.println(Thread.currentThread().getName() + " bloqueó " + archivo2.getNombre());
                
                synchronized (archivo3) {
                    System.out.println(Thread.currentThread().getName() + " bloqueó " + archivo3.getNombre());
                    archivo1.escribir("Datos de " + Thread.currentThread().getName());
                    archivo2.escribir("Datos de " + Thread.currentThread().getName());
                    archivo3.escribir("Datos de " + Thread.currentThread().getName());
                }
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Archivo archivoA = new Archivo("Archivo A");
        Archivo archivoB = new Archivo("Archivo B");
        Archivo archivoC = new Archivo("Archivo C");

        // Pool de hilos con 3 hilos
        ExecutorService pool = Executors.newFixedThreadPool(3);

        // Añadir tareas que intentan acceder a los archivos
        // Cambiamos el orden de los argumentos en las tareas para que todos sigan el mismo orden
        pool.submit(new TareaEscritura(archivoA, archivoB, archivoC)); // A, B, C
        pool.submit(new TareaEscritura(archivoA, archivoB, archivoC)); // A, B, C
        pool.submit(new TareaEscritura(archivoA, archivoB, archivoC)); // A, B, C

        pool.shutdown();

        // Esperar a que todos los hilos finalicen
        try {
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
                System.out.println("Tiempo de espera agotado. Hilos posiblemente en interbloqueo.");
                pool.shutdownNow();
            }
        } catch (InterruptedException e) {
            pool.shutdownNow();
        }
    }
}
