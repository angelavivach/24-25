package interblock;

public class ColaArticulos {
    private int[] articulos = new int[10];
    private int indice = 0;

    public void agregar(int articuloId) {
        articulos[indice++] = articuloId;
    }

    public int remover() {
        return articulos[--indice];
    }

    public boolean estaVacia() {
        return indice == 0;
    }

    public boolean estaLlena() {
        return indice == articulos.length;
    }

    public static void main(String[] args) {
        ColaArticulos colaPendientes = new ColaArticulos();
        ColaArticulos colaRevisados = new ColaArticulos();

        Productor escritor = new Productor(colaPendientes, colaRevisados);
        Consumidor revisor = new Consumidor(colaPendientes, colaRevisados);

        Thread hiloEscritor = new Thread(escritor, "Escritor 1");
        Thread hiloEscritor1 = new Thread(escritor, "Escritor 2");
        Thread hiloEscritor2 = new Thread(escritor, "Escritor 3");
        Thread hiloRevisor = new Thread(revisor, "Revisor");

        hiloEscritor.start();
        hiloEscritor1.start();
        hiloEscritor2.start();
        hiloRevisor.start();
        
        try {
            hiloEscritor.join();
            hiloEscritor1.join();
            hiloEscritor2.join();
        } catch (InterruptedException e) {
            System.out.println("Hilo escritor no ha terminado normalmente");
            e.printStackTrace();
        }
        
        try {
            hiloRevisor.join();    
        } catch (InterruptedException e) {
            System.out.println("Hilo revisor no ha terminado normalmente.");
        }
    }
}

class Productor implements Runnable {
    private ColaArticulos colaPendientes;
    private ColaArticulos colaRevisados;

    public Productor(ColaArticulos colaPendientes, ColaArticulos colaRevisados) {
        this.colaPendientes = colaPendientes;
        this.colaRevisados = colaRevisados;
    }

    @Override
    public void run() {
        while (true) {
            synchronized (colaPendientes) {
                // Esperar si la cola está llena
                while (colaPendientes.estaLlena()) {
                    try {
                        colaPendientes.wait(); // Hilo espera si la cola de pendientes está llena
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                
                // Agregar un artículo a la cola pendientes
                int articuloId = (int) (Math.random() * 1000); // Simulación de artículo
                colaPendientes.agregar(articuloId);
                System.out.println(Thread.currentThread().getName() + " agregó artículo " + articuloId + " a la Cola de Pendientes");
                colaPendientes.notifyAll(); // Notifica a los consumidores
            }
        }
    }
}

class Consumidor implements Runnable {
    private ColaArticulos colaPendientes;
    private ColaArticulos colaRevisados;

    public Consumidor(ColaArticulos colaPendientes, ColaArticulos colaRevisados) {
        this.colaPendientes = colaPendientes;
        this.colaRevisados = colaRevisados;
    }

    @Override
    public void run() {
        while (true) {
            int articuloId;
            synchronized (colaPendientes) {
                // Esperar si la cola está vacía
                while (colaPendientes.estaVacia()) {
                    try {
                        colaPendientes.wait(); // Hilo espera si la cola de pendientes está vacía
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                
                // Remover un artículo de la cola de pendientes
                articuloId = colaPendientes.remover();
                System.out.println(Thread.currentThread().getName() + " removió artículo " + articuloId + " de la Cola de Pendientes");
                colaPendientes.notifyAll(); // Notifica a los productores que hay espacio disponible
            }

            // Procesar el artículo y agregarlo a la cola revisados
            synchronized (colaRevisados) {
                // Esperar si la cola revisados está llena
                while (colaRevisados.estaLlena()) {
                    try {
                        colaRevisados.wait(); // Hilo espera si la cola revisados está llena
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                // Simula un tiempo para el proceso de revisión
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }

                // Agregar el artículo a la cola revisados
                colaRevisados.agregar(articuloId);
                System.out.println(Thread.currentThread().getName() + " agregó artículo " + articuloId + " a la Cola de Revisados");
                colaRevisados.notifyAll(); // Notifica a los productores o consumidores que hay un nuevo artículo
            }
        }
    }
}
