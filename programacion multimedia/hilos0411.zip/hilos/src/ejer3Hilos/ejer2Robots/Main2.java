package ejer3Hilos.ejer2Robots;

public class Main2 {
	public static void main(String[] args) {
        // Crear y lanzar robots exploradores en paralelo
        Thread[] exploradores = new Thread[4];
        for (int i = 0; i < 4; i++) {
            exploradores[i] = new Thread(new RobotExplorador("Explorador " + (i + 1), 5));
            exploradores[i].start();
        }

        // Crear robots constructores
        RobotConstructor[] constructores = new RobotConstructor[3];
        constructores[0] = new RobotConstructor("Constructor A", 2);
        constructores[1] = new RobotConstructor("Constructor B", 3);
        constructores[2] = new RobotConstructor("Constructor C", 4);

        // Ejecutar la operación de construcción secuencialmente
        for (RobotConstructor constructor : constructores) {
            constructor.operar();
        }

        // Comprobar el total de estructuras construidas
        System.out.println("Estructuras totales construidas: " + RobotConstructor.getEstructurasConstruidas());
    }

}
