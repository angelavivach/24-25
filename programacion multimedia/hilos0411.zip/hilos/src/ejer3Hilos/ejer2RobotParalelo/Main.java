package ejer3Hilos.ejer2RobotParalelo;

public class Main {
	public static void main(String[] args) {
        // Crear y lanzar robots exploradores en paralelo
        Thread[] exploradores = new Thread[4];
        for (int i = 0; i < 4; i++) {
            exploradores[i] = new Thread(new RobotExplorador("Explorador " + (i + 1), 5));
            exploradores[i].start();
        }

        // Crear robots constructores
        Thread[] constructores = new Thread[3];
        constructores[0] = new Thread(new RobotConstructor("Constructor A", 2));
        constructores[1] = new Thread(new RobotConstructor("Constructor B", 3));
        constructores[2] = new Thread(new RobotConstructor("Constructor C", 4));

        // Ejecutar la operación de construcción en paralelo
        for (Thread constructor : constructores) {
            constructor.start();
        }

        // Esperar a que terminen los hilos de exploración
        for (Thread explorador : exploradores) {
            try {
                explorador.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Esperar a que terminen los hilos de construcción
        for (Thread constructor : constructores) {
            try {
                constructor.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Comprobar el total de estructuras construidas
        System.out.println("Estructuras totales construidas: " + RobotConstructor.getEstructurasConstruidas());
    }

}
