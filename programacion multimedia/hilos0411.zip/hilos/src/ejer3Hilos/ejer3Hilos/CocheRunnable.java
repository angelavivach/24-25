package ejer3Hilos.ejer3Hilos;

public class CocheRunnable implements Runnable{

	 private String nombre;
	    private int velocidad; 
	    private int distanciaTotal; 

	    public CocheRunnable(String nombre, int velocidad, int distanciaTotal) {
	        this.nombre = nombre;
	        this.velocidad = velocidad;
	        this.distanciaTotal = distanciaTotal;
	    }

	    @Override
	    public void run() {
	        for (int i = 1; i <= distanciaTotal; i++) {
	            try {
	                
	                Thread.sleep(velocidad);
	                System.out.println(nombre + " ha avanzado " + i + " km");
	            } catch (InterruptedException e) {
	                System.out.println(nombre + " ha sido interrumpido.");
	                return;
	            }
	        }
	        System.out.println(nombre + " ha terminado la carrera.");
	    }
	

	
	    public static void main(String[] args) {
	        
	        CocheRunnable coche1 = new CocheRunnable("Opel", 1000, 5);
	        CocheRunnable coche2 = new CocheRunnable("Seat", 800, 7);  
	        CocheRunnable coche3 = new CocheRunnable("Peugeot", 1200, 2); 
	        CocheRunnable coche4 = new CocheRunnable("Cupra", 900, 10);  

	        
	        Thread thread1 = new Thread(coche1);
	        Thread thread2 = new Thread(coche2);
	        Thread thread3 = new Thread(coche3);
	        Thread thread4 = new Thread(coche4);

	        
	        thread1.start();
	        thread2.start();
	        thread3.start();
	        thread4.start();
	    }

}

	


