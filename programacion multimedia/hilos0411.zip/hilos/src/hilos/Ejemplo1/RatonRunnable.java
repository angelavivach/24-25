package hilos.Ejemplo1;

/**
 * Ventajas que puede heredar
 * Inconvenientes al final te hace falta crear y ejecutar el hilo
 */

public class RatonRunnable implements Runnable{

	private String nombre;
	private int tiempoAlimentacion;
	
	public RatonRunnable(String nombre, int tiempoAlimentacion) {
		super();
		this.nombre= nombre;
		this.tiempoAlimentacion = tiempoAlimentacion;
	}

    
	@Override // Se auto genera porque la inteface te obliga a implementar
	public void run() {
		this.comer();
	}
	
	 public void comer() {
		 try {
				System.out.printf("El ratón %s ha comenzado a alimentarse\n",nombre);
				Thread.sleep(tiempoAlimentacion*1000);
				System.out.printf("El ratón %s ha terminado de alimentarse\n", nombre);			
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	 }
	 
	public static void main(String[] args) {
		RatonRunnable Alba = new RatonRunnable("Alba",4);
		RatonRunnable David = new RatonRunnable("David",5);
		RatonRunnable Fernando = new RatonRunnable("Fernando",3);
		RatonRunnable Dani = new RatonRunnable("Dani",7);
		
       //La interfaz no permite todo lo de thread, tenemos que utilizar thread que es la clase que crea hilos
		//Podemos utilizar el constructor de thread
		
		//THREAD tiene un constructor qu epermite un argumento de tipo runnable
	    Thread t1=new Thread (Alba); //creamos hilo
	    t1.start(); //encola el hilo para su ejecucion paralela
	    
	    //(new Thread (Alba)).start(); otra forma de crear y lanzar
	    
	    Thread t2=new Thread (David);
	    t2.start();
	    Thread t3=new Thread (Fernando);
	    t3.start();
	    Thread t4=new Thread (Dani);
	    t4.start();

	}
}
