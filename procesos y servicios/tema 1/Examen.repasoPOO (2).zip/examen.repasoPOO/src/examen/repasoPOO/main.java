package examen.repasoPOO;

import java.util.ArrayList;
import java.util.List;


public class main {

	public static void main(String[] args) {
       persona perso=new persona(null);
       
	   perso.getNombre();
	   
		
	   List <persona>lista=new ArrayList <persona>();
	   lista.add(new persona("Juan"));
	   lista.add(new persona("Ana"));
		
	   coche coch=new coche(null, null, 0, 0, null);
		
	   coch.getMarca();
	   coch.getModelo();
	   coch.getAño();
	   coch.getNumeroPuertas();
	   coch.getPropietario();
		
		List <coche>lista1=new ArrayList <coche>();
		lista1.add(new coche("Toyota", "Corolla",2020, 4, "Juan"));
		lista1.add(new coche("Honda", "Civic", 2021, 4, "Ana"));
		lista1.add(new coche("Ford", "Focus", 2022, 4,"No tiene propietario"));
		
		
			
			System.out.println("---Coche---");
			for (int i=0; i<lista1.size();i++){
				System.out.println("Total vehiculos creados: ");
				System.out.println("Coche 1 propietario: "+ lista1.get(i).getPropietario());
				System.out.println("Coche 2 propietario: "+ lista1.get(i).getPropietario());
				System.out.println("Coche 3 propietario: "+  lista1.get(i).getPropietario());
				
				for (int j=1; i<lista2.size();i++){
					System.out.println("Total vehiculos creados: ");
					System.out.println("Camion 1 propietario: "+ lista2.get(i).getPropietario());
					System.out.println("Criterios de evaluacion");
				}
			}
			


	}

}
