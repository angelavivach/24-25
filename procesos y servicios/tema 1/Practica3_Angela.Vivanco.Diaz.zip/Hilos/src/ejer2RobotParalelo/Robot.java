package ejer2RobotParalelo;

abstract class Robot {
    protected String nombre;
    protected int tiempoOperacion;

    // Constructor
    public Robot(String nombre, int tiempoOperacion) {
        this.nombre = nombre;
        this.tiempoOperacion = tiempoOperacion;
    }

    // Método abstracto
    public abstract void operar();
}
