package ejer2Robots;

abstract class Robot {
		protected String nombre ;
		protected int tiempoOperacion;
		
		public Robot(String nombre, int tiempoOperacion) {
			super();
			this.nombre = nombre;
			this.tiempoOperacion = tiempoOperacion;
		}
		
		// Método abstracto que las subclases deben implementar
	    public abstract void operar();
		
}
