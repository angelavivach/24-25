package Ejercicio2;

import java.util.concurrent.CyclicBarrier;

public class Jugador implements Runnable {
    private int id;
    private int fortuna;
    private Posicion posicionActual;
    private static final CyclicBarrier barrier;  // Sincroniza todos los jugadores
    private final Tablero tablero;
    private boolean activo;  // Indica si el jugador sigue activo (no ha pisado una mina)
    
    static {
        barrier = new CyclicBarrier(4);  // Número de jugadores (4)
    }

    public Jugador(int id, Tablero tablero) {
        this.id = id;
        this.fortuna = 0;
        this.posicionActual = new Posicion(0, 0);  // Inicialización a la esquina superior izquierda
        this.tablero = tablero;
        this.activo = true;
    }

    @Override
    public void run() {
        while (activo && !tablero.hayFinJuego()) {
            realizarMovimiento();
            try {
                barrier.await();  // Sincroniza todos los jugadores
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!activo) {
            System.out.println("Jugador " + id + " ha pisado una mina y está fuera del juego.");
        }
    }

    private void realizarMovimiento() {
        // Logica de movimiento del jugador, por ejemplo, mover aleatoriamente
        if (!activo) return;
        
        // Generamos una nueva posición aleatoria
        int nuevaX = (int) (Math.random() * 15);
        int nuevaY = (int) (Math.random() * 15);
        Posicion nuevaPos = new Posicion(nuevaX, nuevaY);

        if (tablero.actualizarPosicion(nuevaPos, Entidad.JUGADOR, id)) {
            // Si el movimiento es exitoso, verificamos si encontró algo
            Entidad entidad = tablero.getEntidadEnPosicion(nuevaPos);
            switch (entidad) {
                case PEPA:
                    fortuna++;
                    System.out.println("Jugador " + id + " encontró una pepita en " + nuevaPos);
                    break;
                case MINA:
                    activo = false;  // El jugador encuentra una mina y se elimina
                    break;
                case VACIO:
                    // No encuentra nada, solo avanza
                    break;
                default:
                    break;
            }
        }
    }

    public int getFortuna() {
        return fortuna;
    }

    public boolean isActivo() {
        return activo;
    }
}
