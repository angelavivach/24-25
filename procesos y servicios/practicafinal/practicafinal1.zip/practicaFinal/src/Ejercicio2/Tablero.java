package Ejercicio2;

import java.util.concurrent.ConcurrentHashMap;

public class Tablero {
    private final ConcurrentHashMap<Posicion, Entidad> celdas;
    private int pepitasRestantes;
    private int minasRestantes;

    public Tablero() {
        celdas = new ConcurrentHashMap<>();
        pepitasRestantes = 0;
        minasRestantes = 0;
        inicializarTablero();
    }

    private void inicializarTablero() {
        // Llenar el tablero con minas, pepitas y jugadores
        for (int i = 0; i < 4; i++) {
            // Crear jugadores (colocados en posiciones aleatorias)
            Posicion posJugador = new Posicion((int) (Math.random() * 15), (int) (Math.random() * 15));
            celdas.put(posJugador, Entidad.JUGADOR);
        }
        
        // Colocar las pepitas (3 veces más que jugadores)
        for (int i = 0; i < 12; i++) {
            Posicion posPepita = new Posicion((int) (Math.random() * 15), (int) (Math.random() * 15));
            celdas.put(posPepita, Entidad.PEPA);
            pepitasRestantes++;
        }
        
        // Colocar las minas (la mitad que jugadores)
        for (int i = 0; i < 2; i++) {
            Posicion posMina = new Posicion((int) (Math.random() * 15), (int) (Math.random() * 15));
            celdas.put(posMina, Entidad.MINA);
            minasRestantes++;
        }
    }

    public synchronized boolean actualizarPosicion(Posicion pos, Entidad entidad, int idJugador) {
        if (!celdas.containsKey(pos)) {
            // Si no hay nada en la celda, colocar al jugador
            celdas.put(pos, entidad);
            return true;
        }
        return false;  // La celda ya está ocupada
    }

    public synchronized Entidad getEntidadEnPosicion(Posicion pos) {
        return celdas.getOrDefault(pos, Entidad.VACIO);
    }

    public synchronized boolean hayFinJuego() {
        return pepitasRestantes == 0 || minasRestantes == 0;
    }
}

