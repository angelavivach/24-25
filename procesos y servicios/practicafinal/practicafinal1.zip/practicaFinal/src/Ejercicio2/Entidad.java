package Ejercicio2;

public enum Entidad {
    VACIO, PEPA, MINA, JUGADOR;
}

