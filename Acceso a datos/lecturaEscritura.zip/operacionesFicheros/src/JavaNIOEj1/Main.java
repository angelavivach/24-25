package JavaNIOEj1;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class Main {
    public static void crearDirectorio(Path dir) throws IOException {
        if (!Files.exists(dir)) {
            Files.createDirectory(dir);
            System.out.println("Directorio creado en: " + dir.toAbsolutePath() + ", su padre es: " + dir.getParent());
        } else {
            System.out.println("El directorio ya existe en: " + dir.toAbsolutePath());
        }
    }

    public static void escribirArchivo(Path fichero, String texto) throws IOException {
        // Escribe en el archivo, creando uno nuevo si no existe
        Files.writeString(fichero, texto, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        System.out.println("Archivo creado y escrito: " + fichero.toAbsolutePath());
    }

    public static void leerArchivoCompleto(Path fichero) throws IOException {
        String contenidoCompleto = Files.readString(fichero);
        System.out.println("Contenido completo del archivo:\n" + contenidoCompleto);
    }

    public static void leerArchivoLinea(Path fichero) throws IOException {
        // Leer el archivo línea por línea
        List<String> contenidoLeido = Files.readAllLines(fichero);
        System.out.println("Contenido leído línea por línea:");
        for (String linea : contenidoLeido) {
            System.out.println(linea);
        }
    }

    public static void copiarArchivo(Path fichero, Path ficheroCopia) throws IOException {
        Files.copy(fichero, ficheroCopia);
        System.out.println("Archivo copiado a: " + ficheroCopia.toAbsolutePath());
    }

    public static void moverArchivo(Path fichero, Path ficheroCopia) throws IOException {
        Files.move(fichero, ficheroCopia,StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Archivo movido a: " + ficheroCopia.toAbsolutePath());
    }
    
    public static void borrarArchivo(Path fichero) throws IOException {
    	
    		Files.deleteIfExists(fichero);
    		System.out.println("Se ha borrado el archivo " );
    }
    
    public static void main(String[] args) {
        // Definir directorios y archivos
        Path directorio = Paths.get("Carpeta");
        Path directorioCopia = Paths.get("Carpeta2");
        Path fichero = directorio.resolve("ficheroJavaNIO.txt");
        //Path ficheroCopia = ficheroCopia.resolve("ficheroJavaNioCopia.txt");
        Path ficheroCopia = directorioCopia.resolve("ficheroJavaNioCopia.txt");

        try {
            // Crear directorios
            crearDirectorio(directorio);
            crearDirectorio(directorioCopia);
            
            // Escribir en el archivo
            escribirArchivo(fichero, "Hola, ¿qué tal?\n");

            // Leer el archivo completo o línea por línea (descomentar según necesidad)
            // leerArchivoCompleto(fichero);
            // leerArchivoLinea(fichero);
            
            // Copiar y mover el archivo
            // copiarArchivo(fichero, ficheroCopia);  
            moverArchivo(fichero, ficheroCopia); 
            
            borrarArchivo(fichero);
        } catch (IOException e) {
            System.err.println("Ocurrió un error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

