package Fichero;
import java.io.*;

public class Principal {
	
	public static void recursividadDirectorios(File directorio) {
		
		 if(directorio==null) { //lo igualamos a 1 porque sera el ultimo numero por el que se puede multiplicar
	    	  System.out.println("Fin");
	      }else {
	    	  System.out.println(directorio);
	    	  
	      }
		 return;
	}
	
	public static void crearFichero(File f) {
		
		 try {
		      if(!f.exists()) {
		            //Creamos fisicamente el fichero
		           if (f.createNewFile())
			          System.out.println("Fichero creado");
		           else
			          System.out.println("Fichero no ha sido creado");
		     
	          }else
		            System.out.println("El fichero ya existe");
		            //llamo a la funcion verPermisos
		          
		
		            
        }
	     catch(IOException e) {
		     e.printStackTrace();
	     }
	}
	public static void listarFicheros(File d) {
		File[] ficheros=d.listFiles();
		
		for(File f:ficheros) {
			if(f.isFile()) {
				System.out.println(f.getName()+" es un fichero");
			}
			if(f.isDirectory()) {
				System.out.println(f.getName()+" es un directorio");
			}
		}
	}
	
	public static void comprobarDirectorio(File f) {
		if(f.isDirectory()) {
			listarFicheros(f);
		}else {
			if(f.isFile())
				System.out.println("Es un fichero no se puede recorrer");
		}
	}
	
	public static void cambiarPermisos(File f) {
		f.setExecutable(false);
		f.setReadable(false);
		f.setWritable(false);
		
	}
	
	public static void verPermisos(File f) {
		String permisos="";
		//permisos lectura
		if (f.canRead()) {
			permisos=permisos+"r";
		}
		else {
			permisos=permisos+"-";
		}
		// permisos escritura
		if (f.canWrite()) {
			permisos=permisos+"w";
		}
		else {
			permisos=permisos+"-";
		}
		// permisos ejecucion
		if (f.canExecute()) {
			permisos=permisos+"x";
		}
		else {
			permisos=permisos+"-";
		}
		System.out.println("Los permisos del archivo " + f.getName()+ " son: " +permisos);
	}

	public static void main(String[] args) {
		//crear directorio
		String nombreDirectorio=".\\datos\\";
		File directorio =new File(nombreDirectorio);
		// Se escribe el nombre del fichero que se guarda fisicamente
		String nombrefichero = "ficheroNuevo.txt";
		File fichero = new File(nombreDirectorio+nombrefichero);
		
		
		if(!directorio.exists()) {
			System.out.println("el directorio no existe");
			if(directorio.mkdirs()) {
				
				 /* verPermisos(fichero);
		          cambiarPermisos(fichero);
		          verPermisos(fichero);*/
				
		          // fichero.delete();
			   
			}else {
				System.out.println("No se ha podido crear el directorio");
			}
			
		}//Si el directorio no exite 
		else {
			//directorio existe
			System.out.println("El directorio existe");
			 crearFichero(fichero);
		}
		
		comprobarDirectorio(directorio);
		recursividadDirectorios( directorio);
		
	}
}
