package pruebaexamen;

import java.io.*;
import java.util.*;

public class Prueba1 {

    // Clase Clientes para representar los clientes
    static class Clientes {
        String nombre;
        String apellido;
        int edad;
        int id;
        String rol; // Nuevo campo: rol del cliente

        // Constructor de la clase Clientes
        public Clientes(String nombre, String apellido, int edad, int id, String rol) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.id = id;
            this.rol = rol;
        }

        // Getters y setters
        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getApellido() {
            return apellido;
        }

        public void setApellido(String apellido) {
            this.apellido = apellido;
        }

        public int getEdad() {
            return edad;
        }

        public void setEdad(int edad) {
            this.edad = edad;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getRol() {
            return rol;
        }

        public void setRol(String rol) {
            this.rol = rol;
        }
    }

    // Método principal
    public static void main(String[] args) {
        // Lee los clientes desde el archivo y almacena en la lista
        List<Clientes> clientes = leerClientes("prueba1.txt");

        // Iniciar sesión solicitando credenciales al usuario (ejemplo simple)
        Clientes cliente = iniciarSesion(clientes); // Modificado para pasar la lista de clientes

        if (cliente != null) { // Si el usuario ha ingresado correctamente, se ejecutan las siguientes acciones
            switch (cliente.getRol()) { // Dependiendo del rol del usuario
                case "administrador":
                    System.out.println("Bienvenido administrador " + cliente.getNombre());
                    menuAdministrador(clientes); // Pasa la lista de clientes
                    break;
                case "web":
                    System.out.println("Bienvenido web " + cliente.getNombre());
                    break; // Si es lector, solo muestra un mensaje de bienvenida
                case "presencial":
                    System.out.println("Bienvenido " + cliente.getNombre());
                    break; // Si es cliente, muestra un mensaje de bienvenida
                default:
                    System.out.println("Rol desconocido."); 
            }
        } else {
            System.out.println("Error: No se pudo iniciar sesión.");
        }
    }

    // Método que lee los clientes desde un archivo de texto
    public static List<Clientes> leerClientes(String nombreFichero) {
        List<Clientes> clientes = new ArrayList<>(); // Lista donde se almacenarán los clientes

        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreFichero));
            String linea;

            // Bucle para leer línea a línea
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(";"); // Divide la línea usando el delimitador ";"

                if (datos.length == 5) { // Asegurarse de que hay 5 partes en la línea (incluyendo rol)
                    String nombre = datos[0].trim(); // Primer elemento: nombre
                    String apellido = datos[1].trim(); // Segundo elemento: apellido
                    int edad = Integer.parseInt(datos[2].trim()); // Tercer elemento: edad (convertir a int)
                    int id = Integer.parseInt(datos[3].trim()); // Cuarto elemento: id (convertir a int)
                    String rol = datos[4].trim(); // Quinto elemento: rol (administrador, lector, etc.)

                    // Añadir el cliente a la lista de clientes
                    clientes.add(new Clientes(nombre, apellido, edad, id, rol));
                }
            }
            br.close(); // Cerrar el BufferedReader después de leer
        } catch (IOException e) {
            System.out.println("Error al leer el fichero: " + e.getMessage());
        }

        return clientes; // Retorna la lista de clientes
    }

    // Método para iniciar sesión (puede ser simple o complejo, aquí un ejemplo básico)
    public static Clientes iniciarSesion(List<Clientes> clientes) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce tu nombre: ");
        String nombre = scanner.nextLine();

        System.out.println("Introduce tu id: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpia el buffer

        // Búsqueda en la lista de clientes para verificar las credenciales
        for (Clientes cliente : clientes) {
            if (cliente.getNombre().equals(nombre) && cliente.getId() == id) {
                return cliente; // Retorna el cliente si las credenciales coinciden
            }
        }

        System.out.println("Credenciales incorrectas.");
        return null; // Retorna null si no se encuentra el cliente
    }

    // Método para el menú del administrador (ejemplo simple)
    public static void menuAdministrador(List<Clientes> clientes) {
        
        Scanner scanner = new Scanner(System.in); // Scanner para leer entrada del usuario
        while (true) { // Bucle infinito hasta que el administrador elija salir
            // Muestra las opciones disponibles
            System.out.println("\nMenú de administrador:");
            System.out.println("1. Ver usuarios");
            System.out.println("2. Añadir usuario");
            System.out.println("3. Contar usuarios por rol");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt(); // Lee la opción elegida
            scanner.nextLine(); // Limpia el buffer del Scanner

            // Ejecuta la acción correspondiente a la opción seleccionada
            switch (opcion) {
                case 1:
                    mostrarClientes(clientes); // Pasa la lista completa
                    break;
                case 2:
                    agregarClientes(clientes); // Pasa la lista completa
                    break;
                case 3:
                    contarClientesPorRol(clientes); // Pasa la lista completa
                    break;
                case 4:
                    return; // Sale del menú de administrador
                default:
                    System.out.println("Opción no válida."); // Si se introduce una opción incorrecta
            }
        }
    }

    // Función que permite agregar un nuevo usuario, solo accesible por administradores
    public static void agregarClientes(List<Clientes> clientes) {
        Scanner scanner = new Scanner(System.in); // Scanner para leer entrada del usuario
        System.out.println("Introduce el nombre del nuevo usuario:");
        String nombre = scanner.nextLine(); // Lee el nombre del nuevo usuario
        System.out.println("Introduce el apellido del nuevo usuario:");
        String apellido = scanner.nextLine(); 
        System.out.println("Introduce la edad del nuevo usuario:");
        int edad = scanner.nextInt(); // Lee la edad del nuevo usuario
        System.out.println("Introduce el id del nuevo usuario:");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpia el buffer
        System.out.println("Introduce el rol del nuevo usuario (administrador/usuario/lector):");
        String rol = scanner.nextLine(); // Lee el rol del nuevo usuario

        // Se añade el nuevo usuario a la lista
        clientes.add(new Clientes(nombre, apellido, edad, id, rol));
        System.out.println("Usuario añadido correctamente."); // Muestra un mensaje de confirmación
    }

    // Función que muestra los usuarios pero oculta las contraseñas (solo accesible por administradores)
    public static void mostrarClientes(List<Clientes> clientes) {
        System.out.println("Lista de usuarios (contraseñas ocultas):");
        // Itera sobre la lista de usuarios y muestra su nombre, rol y contraseña oculta
        for (Clientes cliente : clientes) {
            System.out.println("Usuario: " + cliente.getNombre() +
                    ", Apellido: " + cliente.getApellido() +
                    ", Edad: " + cliente.getEdad() +
                    ", Id: " + cliente.getId() +
                    ", Rol: " + cliente.getRol());
        }
    }

    // Función que cuenta cuántos usuarios hay de cada tipo (solo accesible por administradores)
    public static void contarClientesPorRol(List<Clientes> clientes) {
        Map<String, Integer> conteo = new HashMap<>(); // Mapa para contar usuarios por rol
        // Itera sobre la lista de usuarios para contar cuántos hay de cada rol
        for (Clientes cliente : clientes) {
            conteo.put(cliente.getRol(), conteo.getOrDefault(cliente.getRol(), 0) + 1);
        }

        // Muestra cuántos usuarios hay de cada tipo
        System.out.println("Conteo por tipo:");
        for (Map.Entry<String, Integer> entry : conteo.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}



