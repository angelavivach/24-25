package pruebaexamen;

import java.io.*; // Importa las clases necesarias para manejar archivos y flujos de entrada/salida
import java.util.*; // Importa clases como List, ArrayList, Scanner, Map, HashMap

// Clase Usuario que contiene los detalles de cada usuario: nombre, contraseña y rol
class Usuario {
    private String nombre;        // Almacena el nombre del usuario
    private String contrasena;    // Almacena la contraseña del usuario
    private String rol;           // Almacena el rol del usuario (administrador, lector, usuario)

    // Constructor de la clase Usuario
    public Usuario(String nombre, String contrasena, String rol) {
        this.nombre = nombre;         // Asigna el nombre del usuario
        this.contrasena = contrasena; // Asigna la contraseña
        this.rol = rol;               // Asigna el rol del usuario
    }

    // Devuelve el nombre del usuario
    public String getNombre() {
        return nombre;
    }

    // Devuelve la contraseña del usuario
    public String getContrasena() {
        return contrasena;
    }

    // Devuelve el rol del usuario
    public String getRol() {
        return rol;
    }

    // Oculta la contraseña mostrando una cantidad de asteriscos equivalente a la longitud de la contraseña
    public String contrasenaOculta() {
        return "*".repeat(contrasena.length());
    }
}

// Clase principal que gestiona la aplicación
public class FichCaracteres {

    public static void main(String[] args) {
        // Leer usuarios desde el fichero "fichPruebaExam.txt"
        List<Usuario> usuarios = leerUsuariosDesdeFichero("fichPruebaExam.txt");

        // Iniciar sesión solicitando credenciales al usuario
        Usuario usuario = iniciarSesion(usuarios);
        if (usuario != null) { // Si el usuario ha ingresado correctamente, se ejecutan las siguientes acciones
            switch (usuario.getRol()) { // Dependiendo del rol del usuario
                case "administrador":
                    System.out.println("Bienvenido administrador " + usuario.getNombre());
                    menuAdministrador(usuarios); // Si es administrador, se muestra el menú de administración
                    break;
                case "lector":
                    System.out.println("Bienvenido lector " + usuario.getNombre());
                    break; // Si es lector, solo muestra un mensaje de bienvenida
                case "usuario":
                    System.out.println("Bienvenido " + usuario.getNombre());
                    break; // Si es usuario, muestra un mensaje de bienvenida
                default:
                    System.out.println("Rol desconocido."); // Si el rol no es válido
            }
        }
    }

    // Función que lee el fichero de usuarios y devuelve una lista de objetos Usuario
    public static List<Usuario> leerUsuariosDesdeFichero(String nombreFichero) {
        List<Usuario> usuarios = new ArrayList<>(); // Lista donde se almacenarán los usuarios
        try (BufferedReader br = new BufferedReader(new FileReader(nombreFichero))) {
            String linea; // Almacena cada línea del archivo
            // Mientras haya líneas en el fichero, se siguen leyendo
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split("[;:]"); // Divide la línea en partes utilizando ';' o ':' como separadores
                if (datos.length == 3) { // Si hay exactamente 3 partes (nombre, contraseña y rol)
                    String nombre = datos[0].trim();       // Primer elemento: el nombre del usuario
                    String contrasena = datos[1].trim();   // Segundo elemento: la contraseña del usuario
                    String rol = datos[2].trim();          // Tercer elemento: el rol del usuario
                    usuarios.add(new Usuario(nombre, contrasena, rol)); // Se añade el usuario a la lista
                }
            }
        } catch (IOException e) { // Captura excepciones relacionadas con la entrada/salida
            System.out.println("Error al leer el fichero: " + e.getMessage()); // Muestra un mensaje de error si ocurre
        }
        return usuarios; // Devuelve la lista de usuarios leída del fichero
    }

    // Función que gestiona el inicio de sesión solicitando credenciales al usuario
    public static Usuario iniciarSesion(List<Usuario> usuarios) {
        Scanner scanner = new Scanner(System.in); // Scanner para leer entrada del usuario
        System.out.println("Introduce tu nombre de usuario:");
        String nombre = scanner.nextLine(); // Se lee el nombre del usuario
        System.out.println("Introduce tu contraseña:");
        String contrasena = scanner.nextLine(); // Se lee la contraseña

        // Verificar si el usuario y la contraseña coinciden con algún usuario en la lista
        for (Usuario usuario : usuarios) {
            if (usuario.getNombre().equals(nombre) && usuario.getContrasena().equals(contrasena)) {
                return usuario; // Si las credenciales son correctas, retorna el usuario
            }
        }
        System.out.println("Usuario o contraseña incorrectos."); // Si no coinciden, muestra un mensaje de error
        return null; // Retorna null si no se encuentra el usuario
    }

    // Función que permite agregar un nuevo usuario, solo accesible por administradores
    public static void agregarUsuario(List<Usuario> usuarios) {
        Scanner scanner = new Scanner(System.in); // Scanner para leer entrada del usuario
        System.out.println("Introduce el nombre del nuevo usuario:");
        String nombre = scanner.nextLine(); // Lee el nombre del nuevo usuario
        System.out.println("Introduce la contraseña del nuevo usuario:");
        String contrasena = scanner.nextLine(); // Lee la contraseña del nuevo usuario
        System.out.println("Introduce el rol del nuevo usuario (administrador/usuario/lector):");
        String rol = scanner.nextLine(); // Lee el rol del nuevo usuario

        // Se añade el nuevo usuario a la lista
        usuarios.add(new Usuario(nombre, contrasena, rol));
        System.out.println("Usuario añadido correctamente."); // Muestra un mensaje de confirmación
    }

    // Función que muestra los usuarios pero oculta las contraseñas (solo accesible por administradores)
    public static void mostrarUsuarios(List<Usuario> usuarios) {
        System.out.println("Lista de usuarios (contraseñas ocultas):");
        // Itera sobre la lista de usuarios y muestra su nombre, rol y contraseña oculta
        for (Usuario usuario : usuarios) {
            System.out.println("Usuario: " + usuario.getNombre() +
                    ", Contraseña: " + usuario.contrasenaOculta() +
                    ", Rol: " + usuario.getRol());
        }
    }

    // Función que cuenta cuántos usuarios hay de cada tipo (solo accesible por administradores)
    public static void contarUsuariosPorRol(List<Usuario> usuarios) {
        Map<String, Integer> conteo = new HashMap<>(); // Mapa para contar usuarios por rol
        // Itera sobre la lista de usuarios para contar cuántos hay de cada rol
        for (Usuario usuario : usuarios) {
            conteo.put(usuario.getRol(), conteo.getOrDefault(usuario.getRol(), 0) + 1);
        }

        // Muestra cuántos usuarios hay de cada tipo
        System.out.println("Usuarios por tipo:");
        for (Map.Entry<String, Integer> entry : conteo.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    // Menú especial para administradores donde pueden ver usuarios, agregar nuevos y contar roles
    public static void menuAdministrador(List<Usuario> usuarios) {
        Scanner scanner = new Scanner(System.in); // Scanner para leer entrada del usuario
        while (true) { // Bucle infinito hasta que el administrador elija salir
            // Muestra las opciones disponibles
            System.out.println("\nMenú de administrador:");
            System.out.println("1. Ver usuarios");
            System.out.println("2. Añadir usuario");
            System.out.println("3. Contar usuarios por rol");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt(); // Lee la opción elegida
            scanner.nextLine(); // Limpia el buffer del Scanner

            // Ejecuta la acción correspondiente a la opción seleccionada
            switch (opcion) {
                case 1:
                    mostrarUsuarios(usuarios); // Muestra la lista de usuarios
                    break;
                case 2:
                    agregarUsuario(usuarios); // Añade un nuevo usuario
                    break;
                case 3:
                    contarUsuariosPorRol(usuarios); // Cuenta usuarios por rol
                    break;
                case 4:
                    return; // Sale del menú de administrador
                default:
                    System.out.println("Opción no válida."); // Si se introduce una opción incorrecta
            }
        }
    }
}


