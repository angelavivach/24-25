package pruebaexamen;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

		public static void crearFichero(String ruta) {
			File fichero = new File(ruta);
			if(!fichero.exists()) {
				try{
					fichero.createNewFile();
					System.out.println("El fichero se está creando...");
				}catch(IOException e) {
					e.printStackTrace();
				}
			}
			else {
				System.out.println("El fichero está creado");
			}
		}
		public static ArrayList<Usuario1> leerFichero(String ruta, ArrayList<Usuario1> listaUsuarios) {
			
			try(BufferedReader br = new BufferedReader(new FileReader(ruta))){
				String linea;
				while((linea=br.readLine())!=null) {
					String partes[]=linea.split(";");
					Usuario1 u = new Usuario1(partes[0],partes[1],partes[2]);
					listaUsuarios.add(u);
				}
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			return listaUsuarios;
		}
		public static void visualizarArray( ArrayList<Usuario1> listaUsuarios) {
			 String pass="";
			 for (int i = 0; i < listaUsuarios.size(); i++) {
				 	Usuario1 u = listaUsuarios.get(i);
				 	for(int j=0;j<u.getPassword().length();j++) {pass=pass+"*";}
		            System.out.println( u.getUsuario()+ ": " + pass);
		            pass="";
		        }
		}
		public static String RecogerDatos(ArrayList<Usuario1> listaUsuarios) {
			 boolean usuarioExiste=false;
		     int i=0;
		     String rol=null;
			
			Scanner scanner = new Scanner(System.in);
			System.out.print("Ingrese el nombre de usuario: ");
	      
			String usuarioIngresado = scanner.nextLine();
	       System.out.print("Ingrese la contraseña: ");
	       String contrasenaIngresada = scanner.nextLine();
	      
	     
	      
	       while((i < listaUsuarios.size())&&(!usuarioExiste)) {	
	       	Usuario1 usuario = listaUsuarios.get(i);
		        // Verificar las credenciales
		        if (usuarioIngresado.equals(usuario.getUsuario()) && contrasenaIngresada.equals(usuario.getPassword())) {
		            rol=usuario.getRol();
		            usuarioExiste=true;
		           
		        }
		        i++;
	       }
	       System.out.println("Usuario existe: "+usuarioExiste);
	       return rol;
		}
		
		public static void contarUsuariosPorRol(ArrayList<Usuario1> usuarios) {
	       // Definir roles conocidos
	       String[] roles = {"administrador", "usuario", "lector"};
	       int[] conteo = new int[roles.length];
	       // Contar los roles
	       for (Usuario1 u : usuarios) {
	           String rol = u.getRol();
	           for (int i = 0; i < roles.length; i++) {
	               if (rol.equals(roles[i])) {
	                   conteo[i]++;
	                   break;
	               }
	           }
	       }
	       // Mostrar conteo
	       System.out.println("Numero de usuarios por rol:");
	       for (int i = 0; i < roles.length; i++) {
	           System.out.println("Rol: " + roles[i] + " : " + conteo[i]);
	       }
	   }
		
		public static int escribirAlumnoEnFichero(String nombreFichero,ArrayList<Usuario1> usuarios) {
	       Scanner scanner = new Scanner(System.in);
	       // Pedir datos al usuario
	       System.out.print("Ingrese el usuario: ");
	       String usuario = scanner.nextLine();
	       System.out.print("Ingrese la contraseña: ");
	       String contrasena = scanner.nextLine();
	       System.out.print("Ingrese el rol: ");
	       String rol = scanner.nextLine();
	      Usuario1 u = new Usuario1(usuario,contrasena,rol);
	     
	       // Escribir en el fichero en modo "añadir"
	       try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreFichero, true))) {
	           bw.write(u.getUsuario()+";"+u.getPassword()+";"+u.getRol());
	           bw.newLine(); // Añadir nueva línea
	           System.out.println("Se ha guardado correctamente");
	       } catch (IOException e) {
	           System.err.println("Error al escribir en el fichero: " + e.getMessage());
	       }
	       scanner.close();
	       return 0;
	   }
		
		public static void funcionesRoles(String rol,String nombreFichero,ArrayList<Usuario1> usuarios) {
			int opcion;
			Scanner scanner = new Scanner(System.in);
			if(rol!=null) {
				if(rol.equals("administrador")) {
					
					do {
			            // Mostrar el menú
			            System.out.println("\n--- Menú ---");
			            System.out.println("1. Añadir usuarios");
			            System.out.println("2. Mostrar usuarios");
			         
			            System.out.println("0. Salir");
			            System.out.print("Seleccione una opción: ");
			            // Leer la opción del usuario
			            opcion = scanner.nextInt();
			            // Procesar la opción seleccionada
			            switch (opcion) {
			                case 1:
			                	opcion=escribirAlumnoEnFichero(nombreFichero,usuarios);
			                    break;
			                case 2:
			                	visualizarArray(usuarios);
			                    break;
			                case 0:
			                    System.out.println("Saliendo del programa...");
			                    break;
			                default:
			                    System.out.println("Opción no válida. Inténtalo de nuevo.");
			            }
			        } while (opcion != 0);
					
				}
				else {
					if(rol.equals("usuario")) {
						contarUsuariosPorRol(usuarios);
					}else {
						if(rol.equals("lector")) {
							System.out.println("Bienvenida");
						}
						else {
							System.out.println("No existe ese ese rol");
						}
					}
				}
			}
				else {
					System.out.println("No existe ese usuario");
					}
			}
		
		public static void main(String[] args) {
			String ruta="usuarios.txt";
			 ArrayList<Usuario1> listaUsuarios = new ArrayList<>();
			crearFichero(ruta);
			listaUsuarios=leerFichero(ruta,listaUsuarios);
			funcionesRoles(RecogerDatos(listaUsuarios),ruta,listaUsuarios);
		}
	

}
