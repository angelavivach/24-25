package pruebaexamen;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Coche implements Serializable {
    private static final long serialVersionUID = 1L;
    int id;
    String modelo;
    String marca;
    String color;
    boolean vendido;

    public Coche(int id, String modelo, String marca, String color) {
        this.id = id;
        this.modelo = modelo;
        this.marca = marca;
        this.color = color;
        this.vendido = false;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Modelo: " + modelo + ", Marca: " + marca + ", Color: " + color + ", Vendido: " + vendido;
    }
}

public class GestionCoches {
    private static List<Coche> coches = new ArrayList<>();
    private static List<Venta> ventas = new ArrayList<>();

    public static void main(String[] args) {
        String filenameCoches = "coches.dat";
        cargarCoches(filenameCoches);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Menú ---");
            System.out.println("1. Mostrar todos los coches");
            System.out.println("2. Buscar coches por marca");
            System.out.println("3. Buscar coches por modelo");
            System.out.println("4. Buscar coches por color");
            System.out.println("5. Buscar coches por varias opciones");
            System.out.println("6. Vender un coche");
            System.out.println("7. Salir");

            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    mostrarCoches();
                    break;
                case 2:
                    System.out.print("Introduce la marca: ");
                    String marca = scanner.nextLine();
                    buscarCoches(marca, null, null);
                    break;
                case 3:
                    System.out.print("Introduce el modelo: ");
                    String modelo = scanner.nextLine();
                    buscarCoches(null, modelo, null);
                    break;
                case 4:
                    System.out.print("Introduce el color: ");
                    String color = scanner.nextLine();
                    buscarCoches(null, null, color);
                    break;
                case 5:
                    System.out.print("Introduce la marca: ");
                    String marcaOpciones = scanner.nextLine();
                    System.out.print("Introduce el modelo: ");
                    String modeloOpciones = scanner.nextLine();
                    buscarCoches(marcaOpciones, modeloOpciones, null);
                    break;
                case 6:
                    System.out.print("Introduce el ID del coche: ");
                    int idCoche = scanner.nextInt();
                    scanner.nextLine(); // Limpiar el buffer
                    System.out.print("Introduce el nombre del comprador: ");
                    String nombreComprador = scanner.nextLine();
                    registrarVenta(idCoche, nombreComprador);
                    break;
                case 7:
                    guardarCoches(filenameCoches);
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private static void cargarCoches(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            coches = (List<Coche>) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("Fichero no encontrado. Se creará uno nuevo.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void guardarCoches(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(coches);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void mostrarCoches() {
        for (Coche coche : coches) {
            System.out.println(coche);
        }
    }

    private static void buscarCoches(String marca, String modelo, String color) {
        for (Coche coche : coches) {
            boolean matches = true;
            if (marca != null && !marca.isEmpty() && !coche.marca.equalsIgnoreCase(marca)) {
                matches = false;
            }
            if (modelo != null && !modelo.isEmpty() && !coche.modelo.equalsIgnoreCase(modelo)) {
                matches = false;
            }
            if (color != null && !color.isEmpty() && !coche.color.equalsIgnoreCase(color)) {
                matches = false;
            }
            if (matches) {
                System.out.println(coche);
            }
        }
    }

    private static void registrarVenta(int idCoche, String nombreComprador) {
        for (Coche coche : coches) {
            if (coche.id == idCoche && !coche.vendido) {
                coche.vendido = true;
                ventas.add(new Venta(ventas.size() + 1, idCoche, nombreComprador));
                System.out.println("Venta registrada: ID Venta: " + (ventas.size()) + ", ID Coche: " + idCoche);
                return;
            }
        }
        System.out.println("El coche no está disponible para la venta.");
    }
}

class Venta implements Serializable {
    private static final long serialVersionUID = 1L;
    int idVenta;
    int idCoche;
    String nombreComprador;

    public Venta(int idVenta, int idCoche, String nombreComprador) {
        this.idVenta = idVenta;
        this.idCoche = idCoche;
        this.nombreComprador = nombreComprador;
    }
}

