package FicherosAccesoAleatorio;

import java.io.*;

public class MainAleatorio {
	
	public static void EscribirFicheroAleatorio(RandomAccessFile raf, int id, String nombre, double nota )throws IOException {
		raf.writeInt(id);
		raf.writeUTF(nombre);
		raf.writeDouble(nota);
	}
	public static Estudiante LeerEstudiantesFicheroAleatorio(RandomAccessFile raf) throws IOException{
		Estudiante e= new Estudiante(raf.readInt(),raf.readUTF(),raf.readDouble());
		return e;
	}
	public static void anadirEstudiante(String nombreFichero,int id, String nombre, double nota) {
		try(RandomAccessFile raf=new RandomAccessFile(nombreFichero,"rw")){
			raf.seek(raf.length());
			EscribirFicheroAleatorio(raf,id,nombre,nota);	
		}
		catch(IOException e) {
			System.out.println("Error: al abrir fichero para escritura");
			e.printStackTrace();
		}
	}
	public static void ListarEstudiantes(String nombreFichero) {
		try(RandomAccessFile raf=new RandomAccessFile(nombreFichero,"r")){
			while(raf.getFilePointer()<raf.length()) {
				Estudiante estudiante = LeerEstudiantesFicheroAleatorio(raf);
				System.out.println(estudiante);
			}
		}catch(IOException e) {
			System.out.println("Error: al abrir fichero para lectura");
			e.printStackTrace();
		}
	}
	public static Estudiante buscarEstudiantePorID(String nombreFichero, int id) {
		try(RandomAccessFile raf=new RandomAccessFile(nombreFichero,"r")){
			while(raf.getFilePointer()<raf.length()) {
				Estudiante estudiante = LeerEstudiantesFicheroAleatorio(raf);
				if(estudiante.getId()==id) {
					return estudiante;
				}
			}
		}catch(IOException e) {
			System.out.println("Error: al abrir fichero para lectura para buscar");
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String[] args) {
		String nombreFichero="Estudiantes.dat";
		
		anadirEstudiante(nombreFichero,1, "Dionisio", 10.00);
		anadirEstudiante(nombreFichero,2, "Clotilde", 5.00);
		anadirEstudiante(nombreFichero,3, "Teodora", 7.00);
		anadirEstudiante(nombreFichero,4, "Eustaquio", 8.00);
		
		ListarEstudiantes(nombreFichero);
		
		Estudiante e=buscarEstudiantePorID(nombreFichero,2);
		if(e!=null) {
			System.out.println("Se ha encontrado el estudiante "+e);
		}else
			System.out.println("No existe un estudiante con ese ID");
	}
	}
