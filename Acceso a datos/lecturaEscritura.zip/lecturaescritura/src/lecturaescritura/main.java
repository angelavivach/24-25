package lecturaescritura;
import java.io.*;

public class main {
	public static void LecturaBuffer(File fichero) {
		
		
		try {
			FileReader salida = new FileReader(fichero);
			BufferedReader buffer = new BufferedReader(salida);
			String texto;
			
			//System.out.println(buffer.readLine()); //lee una linea
			
			//con el leeemos todas las lineas
			while((texto=buffer.readLine())!=null) {
				System.out.println(texto);
			}
			
			salida.close();
		}catch(Exception e){
			e.getStackTrace();
		}
	}

	
	public static void Lectura(File fichero) {
		char[] texto = new char [100];
		
		try {
			FileReader salida = new FileReader(fichero);
			System.out.println("La codificacion es: " + salida.getEncoding());
			salida.read(texto,0,8);
			System.out.println("El texto es : " );
			System.out.println(texto);
			salida.close();
			
		}catch(Exception e){
			e.getStackTrace();
		}
	}
	
	public static void Escritura2(String ruta) {
		try {
			FileWriter fichero = new FileWriter(ruta,true);//con el true me encadena con lo anterior
			BufferedWriter bw = new BufferedWriter(fichero);
			
			for(int i=22;i<30;i++) {
				bw.write(" "+i);
				bw.newLine(); //salto de linea
			}
			bw.close();
		}catch(Exception e){
			e.getStackTrace();
		}
		
	}
	
	public static void Escritura(String ruta) {
		try {
			FileWriter fichero = new FileWriter(ruta);
			PrintWriter pw = new PrintWriter(fichero);
			
			for(int i=0;i<10;i++) {
				pw.println("numero " +i);
			}
			fichero.close(); //si no cerramos a veces no funciona
		}catch(Exception e) {
			e.getStackTrace();
			}
	}

	public static void main(String[] args) {
		//String ruta="\"";
		String ruta="C:\\Users\\CFGS.LAB-35-PC13.000\\eclipse-workspace-accesodatos\\lecturaescritura\\fichero.txt";
		
		File fichero = new File(ruta);
		
		if(fichero.exists()) {
			System.out.println("Leyendo...");
			//Llamamos a la funcion lectura
			//Lectura(fichero);
			Escritura(ruta); //sobre escribe
			Escritura2(ruta);//con el parametro true encadena
			LecturaBuffer(fichero);
			
		}else {
			System.out.println("No existe el fichero");
		}

	}

}
