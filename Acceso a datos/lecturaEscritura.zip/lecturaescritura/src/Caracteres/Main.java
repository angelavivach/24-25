package Caracteres;

import java.io.*;

public class Main {
	
	private static String[][] leerVentas(String nombreFichero,String[][]datos ) {
		String linea;
		try(BufferedReader bf= new BufferedReader(new FileReader(nombreFichero))){
			int numeroProducto=datos.length;
			while((linea =  bf.readLine())!= null) { //hago la asignacion y con ello compruebo si es distinto de null 
				 String[] partes = linea.split(",");
				 //partes[0] tiene el nombre producto
				 //partes[1] tiene la cantidad en forma String
				
				
				 int indice=0;
				 boolean encontrado=false;
				 
				 while(indice <numeroProducto && !encontrado) {
					  if(datos[indice][0].equals(partes[0])) 
						 encontrado=true;
					 else {
						 indice++; 
						 encontrado=true;
					 }
					 
					 //si encontrado es true
					 if(encontrado) {
						 //es el primero
						 if(datos [indice][1]==null){
							 datos[indice][0]=partes[0];
							 datos[indice][1]=partes[1];
						 }else {
						 //ya existe el producto porque apunta a su posicion
						 int cantidad= Integer.parseInt(datos [indice][1])+Integer.parseInt(partes[0]); //comprueba el primer argumento, una cadena, e intenta devolver un entero de la base especificada
						 
						 datos[indice][1]=String.valueOf(cantidad);//lo convierto en un caracter
						 }
					 }else {
						 //añade el elemento
						 //en dinamico add
						 datos[numeroProducto][0]=partes[0];
						 datos[numeroProducto][1]=partes[1];
					 }
				 }
			}
			bf.close();
			}catch(IOException e) {
			e.printStackTrace();
		}
		return datos;
	}
	
	public static void visualizarDatos(String[][]datos) {
		int i=0;
		while(datos[i][0]!=null) {
			System.out.println(datos[i][0] + " : ");
			System.out.println(datos[i][1]);
		}
	}
	
	public static void crearFichero(String nombreFichero) throws IOException  {
		File Fichero=new File(nombreFichero);
		
		if(!Fichero.exists()) {
			if(Fichero.createNewFile()) {
				System.out.println("Crea fichero ");
			}
		}
	}

	public static void main(String[] args) {
		String[][]datos = new String[100][2]; //max,100 productos y posicion 2
		String nombreFichero ="ventasProducto.txt";
		
		try {
		crearFichero(nombreFichero);
		}catch (IOException e){
			e.printStackTrace();
		}
		visualizarDatos (leerVentas( nombreFichero,datos ));

	}

}
