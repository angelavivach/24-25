package Binario;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
	private List<Habitacion> habitaciones;
    private final String archivo = "habitaciones.bin";

    public Hotel(int numHabitaciones) {
        habitaciones = new ArrayList<>();
        for (int i = 1; i <= numHabitaciones; i++) {
            habitaciones.add(new Habitacion(i));
        }
        cargarHabitaciones();
    }

    private void cargarHabitaciones() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            habitaciones = (List<Habitacion>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // Si no existe el archivo, se crea uno nuevo
            guardarHabitaciones();
        }
    }

    public void guardarHabitaciones() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(habitaciones);
        } catch (IOException e) {
            System.err.println("Error al guardar habitaciones: " + e.getMessage());
        }
    }

    public void reservarHabitacion(int numero, LocalDate fechaEntrada, int diasReservados, String huesped) {
        if (numero < 1 || numero > habitaciones.size()) {
            System.out.println("Número de habitación no válido.");
            return;
        }
        Habitacion habitacion = habitaciones.get(numero - 1);
        if (!habitacion.isOcupada()) {
            habitacion.reservar(fechaEntrada, diasReservados, huesped);
            guardarHabitaciones();
            System.out.println("Habitación " + numero + " reservada con éxito.");
        } else {
            System.out.println("La habitación " + numero + " ya está ocupada.");
        }
    }

    public void liberarHabitacion(int numero) {
        if (numero < 1 || numero > habitaciones.size()) {
            System.out.println("Número de habitación no válido.");
            return;
        }
        Habitacion habitacion = habitaciones.get(numero - 1);
        if (habitacion.isOcupada()) {
            habitacion.liberar();
            guardarHabitaciones();
            System.out.println("Habitación " + numero + " liberada con éxito.");
        } else {
            System.out.println("La habitación " + numero + " ya está libre.");
        }
    }

    public int contarHabitacionesLibres() {
        return (int) habitaciones.stream().filter(h -> !h.isOcupada()).count();
    }

    public double calcularMediaOcupaciones() {
        int totalDias = 0;
        int totalHabitacionesOcupadas = 0;

        for (Habitacion habitacion : habitaciones) {
            if (habitacion.isOcupada()) {
                totalDias += habitacion.getDiasReservados();
                totalHabitacionesOcupadas++;
            }
        }

        return totalHabitacionesOcupadas > 0 ? (double) totalDias / totalHabitacionesOcupadas : 0;
    }

    public List<String> listarHuespedes() {
        List<String> huespedes = new ArrayList<>();
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.isOcupada()) {
                huespedes.add(habitacion.getHuesped());
            }
        }
        return huespedes;
    }

    public void mostrarEstadoHabitaciones() {
        for (Habitacion habitacion : habitaciones) {
            System.out.println("Habitación " + habitacion.getNumero() + ": " + habitacion.estado());
        }
    }

}
