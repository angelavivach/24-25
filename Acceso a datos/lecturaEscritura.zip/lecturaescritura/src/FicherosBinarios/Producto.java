package FicherosBinarios;

import java.io.Serializable;

// Clase base Producto
class Producto implements Serializable {
    protected String titulo;
    protected double precio;

    public Producto(String titulo, double precio) {
        this.titulo = titulo;
        this.precio = precio;
    }

    public String getTitulo() {
        return titulo;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return "'" + titulo + "', Precio: $" + precio;
    }
}
